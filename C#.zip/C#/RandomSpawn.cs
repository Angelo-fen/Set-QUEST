using UnityEngine;
using UnityEngine.UI;

public class RandomSpawn : MonoBehaviour
{
    [Header("Configuraci�n UI")]
    [SerializeField] private Button botonActivar; // Campo para designar el bot�n

    [Header("Objetos")]
    [SerializeField] private GameObject[] objetosArray; // Campo para el array de GameObjects

    private void Start()
    {
        // Suscribir el evento del bot�n por c�digo
        if (botonActivar != null)
        {
            botonActivar.onClick.AddListener(ApagarYActivarAleatorio);
        }
        else
        {
            Debug.LogWarning("El campo 'Boton Activar' no est� asignado en el Inspector.", this);
        }
    }

    private void OnDestroy()
    {
        // Buena pr�ctica: limpiar el listener al destruir el objeto
        if (botonActivar != null)
        {
            botonActivar.onClick.RemoveListener(ApagarYActivarAleatorio);
        }
    }

    /// <label>Apaga todos los objetos del array y enciende uno solo de forma aleatoria.</label>
    public void ApagarYActivarAleatorio()
    {
        // Validar que el array tenga elementos
        if (objetosArray == null || objetosArray.Length == 0)
        {
            Debug.LogWarning("El array de GameObjects est� vac�o o no asignado.", this);
            return;
        }

        // 1. Apagar todos los GameObjects del array
        foreach (GameObject obj in objetosArray)
        {
            if (obj != null)
            {
                obj.SetActive(false);
            }
        }

        // 2. Elegir un �ndice aleatorio dentro del tama�o del array
        int indiceAleatorio = Random.Range(0, objetosArray.Length);

        // 3. Encender �nicamente el objeto seleccionado de forma aleatoria
        if (objetosArray[indiceAleatorio] != null)
        {
            objetosArray[indiceAleatorio].SetActive(true);
        }
    }
}