using UnityEngine;
using UnityEngine.UI;

[ExecuteAlways]
public class Camara : MonoBehaviour
{
    [Header("Referencias")]
    public Camera cam;
    public Transform target;

    [Header("Collider del Player (centro del target)")]
    [Tooltip("Collider que representa el centro del player. Se usa para evitar que el player traspase otros colliders.")]
    public Collider playerCollider;

    [Header("Posici�n relativa")]
    [Tooltip("Distancia desde la c�mara al target.")]
    public float distance = 5f;
    [Tooltip("Altura (offset vertical) aplicada al punto de mira del target.")]
    public float height = 1.5f;
    [Tooltip("Distancia m�nima permitida entre c�mara y target.")]
    public float minDistance = 0.5f;

    [Header("Rotaci�n inicial (grados)")]
    [Tooltip("�ngulo de pitch (rotaci�n X) inicial en grados.")]
    public float rotationX = 20f;
    [Tooltip("�ngulo de yaw (rotaci�n Y) inicial en grados.")]
    public float rotationY = 0f;

    [Header("L�mites de pitch")]
    public float minRotationX = -30f;
    public float maxRotationX = 80f;

    [Header("Sensibilidades")]
    [Tooltip("Sensibilidad horizontal (yaw).")]
    // Empiezan en 0.2f como pediste
    public float rotationSpeedY = 0.2f;
    [Tooltip("Sensibilidad vertical (pitch).")]
    public float rotationSpeedX = 0.2f;
    public bool invertX = false;
    public bool invertY = false;

    [Header("UI Sliders (opcional)")]
    [Tooltip("Slider del Canvas que controla rotationSpeedY (sensibilidad horizontal). Debe usar Min=0 y Max=1.")]
    public Slider rotationSpeedYSlider;
    [Tooltip("Slider del Canvas que controla rotationSpeedX (sensibilidad vertical). Debe usar Min=0 y Max=1.")]
    public Slider rotationSpeedXSlider;

    [Header("Bot�n de reset (opcional)")]
    [Tooltip("Bot�n del Canvas que resetea ambos sliders y sensibilidades a 0.2f.")]
    public Button resetSlidersButton;

    [Header("Suavizado")]
    [Range(0f, 20f)]
    public float smoothSpeed = 8f;

    [Header("Colisi�n de c�mara")]
    [Tooltip("Radio usado para la spherecast de la c�mara (evita que la c�mara atraviese esquinas).")]
    public float cameraCollisionRadius = 0.25f;
    [Tooltip("Offset m�nimo desde la superficie cuando la c�mara se acerca por colisi�n.")]
    public float cameraCollisionOffset = 0.08f;
    [Tooltip("Capas que la c�mara debe considerar como obst�culos.")]
    public LayerMask collisionLayers = ~0;

    // Estado interno
    private float yaw;   // rotaci�n Y en grados
    private float pitch; // rotaci�n X en grados
    private Vector3 velocity = Vector3.zero;
    private Vector3 desiredPosition;
    private bool isDragging = false;
    private Vector2 lastPointerPos;

    // Valor por defecto para reset
    private const float DefaultSensitivity = 0.2f;

    void Reset()
    {
        if (cam == null) cam = GetComponent<Camera>();
    }

    void Start()
    {
        if (cam == null) cam = GetComponent<Camera>();
        if (target == null) Debug.LogError("Camara: asigna el campo 'target' en el inspector.");

        // Asegurar valores iniciales
        rotationSpeedY = DefaultSensitivity;
        rotationSpeedX = DefaultSensitivity;

        yaw = rotationY;
        pitch = rotationX;
        ClampPitch();
        UpdateCameraImmediate();

        // Inicializar sliders si est�n asignados
        if (rotationSpeedYSlider != null)
        {
            rotationSpeedYSlider.minValue = 0f;
            rotationSpeedYSlider.maxValue = 1f;
            rotationSpeedYSlider.wholeNumbers = false;
            rotationSpeedYSlider.value = Mathf.Clamp01(rotationSpeedY);
            // Listener para actualizar en tiempo real (usa valor 0..1 directamente)
            rotationSpeedYSlider.onValueChanged.RemoveListener(SetRotationSpeedY_FromSlider01);
            rotationSpeedYSlider.onValueChanged.AddListener(SetRotationSpeedY_FromSlider01);
        }

        if (rotationSpeedXSlider != null)
        {
            rotationSpeedXSlider.minValue = 0f;
            rotationSpeedXSlider.maxValue = 1f;
            rotationSpeedXSlider.wholeNumbers = false;
            rotationSpeedXSlider.value = Mathf.Clamp01(rotationSpeedX);
            rotationSpeedXSlider.onValueChanged.RemoveListener(SetRotationSpeedX_FromSlider01);
            rotationSpeedXSlider.onValueChanged.AddListener(SetRotationSpeedX_FromSlider01);
        }

        // Conectar bot�n de reset si est� asignado
        if (resetSlidersButton != null)
        {
            resetSlidersButton.onClick.RemoveListener(ResetSlidersToDefault);
            resetSlidersButton.onClick.AddListener(ResetSlidersToDefault);
        }
    }

    void OnDestroy()
    {
        // Limpiar listeners para evitar duplicados en editor
        if (rotationSpeedYSlider != null) rotationSpeedYSlider.onValueChanged.RemoveListener(SetRotationSpeedY_FromSlider01);
        if (rotationSpeedXSlider != null) rotationSpeedXSlider.onValueChanged.RemoveListener(SetRotationSpeedX_FromSlider01);
        if (resetSlidersButton != null) resetSlidersButton.onClick.RemoveListener(ResetSlidersToDefault);
    }

    void LateUpdate()
    {
        if (cam == null) cam = GetComponent<Camera>();
        if (cam == null || target == null) return;

        HandleInput();

        if (playerCollider != null)
        {
            ResolvePlayerPenetration();
        }

        Vector3 targetPoint = target.position + Vector3.up * height;

        Quaternion rot = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 offset = rot * new Vector3(0f, 0f, -Mathf.Abs(distance));
        Vector3 rawDesiredPos = targetPoint + offset;

        Vector3 dir = (rawDesiredPos - targetPoint);
        float rawDistance = dir.magnitude;
        Vector3 finalCamPos = rawDesiredPos;

        if (rawDistance > 0.001f)
        {
            dir /= rawDistance;
            RaycastHit hit;
            if (Physics.SphereCast(targetPoint, cameraCollisionRadius, dir, out hit, rawDistance, collisionLayers, QueryTriggerInteraction.Ignore))
            {
                float hitDist = Mathf.Max(hit.distance - cameraCollisionOffset, 0.01f);
                finalCamPos = targetPoint + dir * hitDist;
            }
        }

        float distToTargetPoint = Vector3.Distance(finalCamPos, targetPoint);
        if (distToTargetPoint < minDistance)
        {
            Vector3 safeDir = (finalCamPos - targetPoint).sqrMagnitude > 0.0001f ? (finalCamPos - targetPoint).normalized : (cam.transform.position - targetPoint).normalized;
            if (safeDir.sqrMagnitude < 0.0001f) safeDir = Vector3.back;
            finalCamPos = targetPoint + safeDir * minDistance;
        }

        if (playerCollider != null)
        {
            float minFromPlayer = Mathf.Max(GetPlayerRadiusEstimate() + 0.05f, minDistance);
            float distToPlayerCenter = Vector3.Distance(finalCamPos, target.position);
            if (distToPlayerCenter < minFromPlayer)
            {
                finalCamPos = target.position + (finalCamPos - target.position).normalized * minFromPlayer;
            }
        }

        desiredPosition = finalCamPos;

        if (smoothSpeed > 0f)
        {
            cam.transform.position = Vector3.SmoothDamp(cam.transform.position, desiredPosition, ref velocity, 1f / smoothSpeed);
        }
        else
        {
            cam.transform.position = desiredPosition;
        }

        cam.transform.LookAt(targetPoint);
    }

    private void UpdateCameraImmediate()
    {
        if (cam == null || target == null) return;
        Vector3 targetPoint = target.position + Vector3.up * height;
        Quaternion rot = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 offset = rot * new Vector3(0f, 0f, -Mathf.Abs(distance));
        Vector3 pos = targetPoint + offset;

        Vector3 dir = (pos - targetPoint);
        if (dir.magnitude < minDistance)
        {
            pos = targetPoint + (dir.sqrMagnitude > 0.0001f ? dir.normalized * minDistance : Vector3.back * minDistance);
        }

        cam.transform.position = pos;
        cam.transform.LookAt(targetPoint);
    }

    private void HandleInput()
    {
        float mitadPantalla = Screen.width * 0.5f;

        if (Input.touchCount > 0)
        {
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                if (t.position.x <= mitadPantalla) continue;

                if (t.phase == TouchPhase.Began)
                {
                    isDragging = true;
                    lastPointerPos = t.position;
                }
                else if (t.phase == TouchPhase.Moved && isDragging)
                {
                    Vector2 delta = t.deltaPosition;
                    ApplyRotationFromDelta(delta);
                    lastPointerPos = t.position;
                }
                else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                {
                    isDragging = false;
                }

                return;
            }

            isDragging = false;
            return;
        }

#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 mouseDownPos = Input.mousePosition;
            if (mouseDownPos.x > mitadPantalla)
            {
                isDragging = true;
                lastPointerPos = mouseDownPos;
            }
            else
            {
                isDragging = false;
            }
        }
        else if (Input.GetMouseButton(0) && isDragging)
        {
            Vector2 current = (Vector2)Input.mousePosition;
            Vector2 delta = current - lastPointerPos;
            ApplyRotationFromDelta(delta);
            lastPointerPos = current;
        }
        else if (Input.GetMouseButtonUp(0))
        {
            isDragging = false;
        }
#endif
    }

    private void ApplyRotationFromDelta(Vector2 delta)
    {
        float dirY = invertY ? -1f : 1f;
        float dirX = invertX ? -1f : 1f;

        yaw += delta.x * rotationSpeedY * dirY;
        pitch -= delta.y * rotationSpeedX * dirX;

        ClampPitch();
        if (yaw > 360f) yaw -= 360f;
        else if (yaw < -360f) yaw += 360f;
    }

    private void ClampPitch()
    {
        pitch = Mathf.Clamp(pitch, minRotationX, maxRotationX);
    }

    private float GetPlayerRadiusEstimate()
    {
        if (playerCollider == null) return 0.5f;
        SphereCollider sc = playerCollider as SphereCollider;
        if (sc != null) return Mathf.Max(sc.radius * Mathf.Max(playerCollider.transform.lossyScale.x, playerCollider.transform.lossyScale.y, playerCollider.transform.lossyScale.z), 0.01f);

        CapsuleCollider cc = playerCollider as CapsuleCollider;
        if (cc != null) return Mathf.Max(cc.radius * Mathf.Max(playerCollider.transform.lossyScale.x, playerCollider.transform.lossyScale.z), 0.01f);

        BoxCollider bc = playerCollider as BoxCollider;
        if (bc != null)
        {
            Vector3 s = Vector3.Scale(bc.size, playerCollider.transform.lossyScale);
            return Mathf.Max(Mathf.Min(s.x, Mathf.Min(s.y, s.z)) * 0.5f, 0.01f);
        }

        return 0.5f;
    }

    private void ResolvePlayerPenetration()
    {
        Vector3 center = playerCollider.bounds.center;
        float radius = GetPlayerRadiusEstimate() + 0.01f;

        Collider[] overlaps = Physics.OverlapSphere(center, radius + 0.05f, collisionLayers, QueryTriggerInteraction.Ignore);
        foreach (var other in overlaps)
        {
            if (other == playerCollider) continue;

            Vector3 direction;
            float distance;
            bool penetrated = Physics.ComputePenetration(
                playerCollider, playerCollider.transform.position, playerCollider.transform.rotation,
                other, other.transform.position, other.transform.rotation,
                out direction, out distance);

            if (penetrated && distance > 0.0001f)
            {
                Vector3 separation = direction * distance;

                Rigidbody rb = target.GetComponent<Rigidbody>();
                if (rb != null && !rb.isKinematic)
                {
                    rb.MovePosition(rb.position + separation);
                }
                else
                {
                    target.position += separation;
                }
            }
        }
    }

    // --- Nueva funci�n p�blica para asignar al OnClick del bot�n ---
    // Gira la c�mara 180 grados alrededor del punto objetivo (target + height) manteniendo distancia y altura.
    public void RotateAroundPlayer180()
    {
        if (cam == null || target == null) return;

        Vector3 targetPoint = target.position + Vector3.up * height;

        // Vector desde el punto objetivo hasta la c�mara
        Vector3 toCam = cam.transform.position - targetPoint;

        // Rotamos 180 grados alrededor del eje up del target (usamos Vector3.up para mundo o target.up si prefieres local)
        Vector3 rotated = Quaternion.AngleAxis(180f, Vector3.up) * toCam;

        // Aplicar nueva posici�n y forzar LookAt
        cam.transform.position = targetPoint + rotated;

        // Actualizar yaw para que los controles sigan coherentes
        yaw += 180f;
        if (yaw > 360f) yaw -= 360f;
        else if (yaw < -360f) yaw += 360f;

        // Asegurar que la c�mara mire al punto objetivo inmediatamente
        cam.transform.LookAt(targetPoint);
    }

    // M�todos p�blicos para conectar desde OnValueChanged del Slider
    // Estos m�todos esperan el valor del slider en 0..1 y lo usan directamente (decimales incluidos).
    public void SetRotationSpeedY_FromSlider01(float slider01)
    {
        rotationSpeedY = Mathf.Clamp01(slider01);
    }

    public void SetRotationSpeedX_FromSlider01(float slider01)
    {
        rotationSpeedX = Mathf.Clamp01(slider01);
    }

    // M�todo para resetear ambos sliders y sensibilidades a DefaultSensitivity (0.2f)
    public void ResetSlidersToDefault()
    {
        rotationSpeedY = DefaultSensitivity;
        rotationSpeedX = DefaultSensitivity;

        if (rotationSpeedYSlider != null) rotationSpeedYSlider.value = DefaultSensitivity;
        if (rotationSpeedXSlider != null) rotationSpeedXSlider.value = DefaultSensitivity;
    }

    void OnDrawGizmosSelected()
    {
        if (target != null)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(target.position + Vector3.up * height, 0.05f);
        }

        if (playerCollider != null)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(playerCollider.bounds.center, GetPlayerRadiusEstimate());
        }

        if (cam != null)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawWireSphere(cam.transform.position, cameraCollisionRadius);
        }
    }
}
