using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

public class Reiniciar : MonoBehaviour
{
    [Header("Bot�n de reiniciar")]
    [SerializeField] private Button reiniciarButton;

    [Header("Array de vidas")]
    [SerializeField] private GameObject[] vidas;

    [Header("Targets")]
    [SerializeField] private Transform targetEnemigo;
    [SerializeField] private Transform targetPlayer;

    [Header("Panel de perdiste")]
    [SerializeField] private GameObject panelPerdiste;

    [Header("GameObjects")]
    [SerializeField] private GameObject player;
    [SerializeField] private GameObject enemigo;

    private void OnEnable()
    {
        if (reiniciarButton != null)
        {
            reiniciarButton.onClick.AddListener(ReiniciarPartida);
        }
    }

    private void OnDisable()
    {
        if (reiniciarButton != null)
        {
            reiniciarButton.onClick.RemoveListener(ReiniciarPartida);
        }
    }

    public void ReiniciarPartida()
    {
        // Activar todos los objetos del array Vidas
        if (vidas != null)
        {
            foreach (GameObject vida in vidas)
            {
                if (vida != null)
                {
                    vida.SetActive(true);
                }
            }
        }

        // Teletransportar Player
        TeletransportarConNavMesh(player, targetPlayer);

        // Teletransportar Enemigo
        TeletransportarConNavMesh(enemigo, targetEnemigo);

        // Apagar panel
        if (panelPerdiste != null)
        {
            panelPerdiste.SetActive(false);
        }
    }

    private void TeletransportarConNavMesh(GameObject objeto, Transform destino)
    {
        if (objeto == null || destino == null)
            return;

        NavMeshAgent agent = objeto.GetComponent<NavMeshAgent>();

        if (agent != null)
        {
            agent.ResetPath();

            if (!agent.Warp(destino.position))
            {
                // Fallback por si falla el Warp
                agent.enabled = false;
                objeto.transform.position = destino.position;
                agent.enabled = true;
            }
        }
        else
        {
            objeto.transform.position = destino.position;
        }
    }
}