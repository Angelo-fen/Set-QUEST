using UnityEngine;

public class LobySonidoNO : MonoBehaviour
{
    [Header("Objeto Normal y su Sombra")]
    [Tooltip("El GameObject principal que se va a monitorear.")]
    public GameObject targetGameObject;

    [Tooltip("El GameObject 'sombra' que tendr� exactamente el mismo estado que el Target GameObject.")]
    public GameObject shadowTargetGameObject;

    [Header("Objeto Especial y su Sombra")]
    [Tooltip("El GameObject especial cuyo estado ser� siempre el opuesto al principal.")]
    public GameObject specialGameObject;

    [Tooltip("El GameObject 'sombra' que tendr� exactamente el mismo estado que el Special GameObject.")]
    public GameObject shadowSpecialGameObject;

    void Update()
    {
        // Validar que el objeto principal exista
        if (targetGameObject == null) return;

        // Comprobar si el objeto principal est� activo en la escena
        bool isTargetActive = targetGameObject.activeSelf;

        // 1. Sombra del objeto normal copia el estado del objeto normal
        if (shadowTargetGameObject != null)
        {
            if (shadowTargetGameObject.activeSelf != isTargetActive)
            {
                shadowTargetGameObject.SetActive(isTargetActive);
            }
        }

        // El estado del objeto especial es el opuesto (inverso) al principal
        bool desiredSpecialState = !isTargetActive;

        // 2. Aplicar estado al objeto especial
        if (specialGameObject != null)
        {
            if (specialGameObject.activeSelf != desiredSpecialState)
            {
                specialGameObject.SetActive(desiredSpecialState);
            }
        }

        // 3. La sombra del objeto especial copia el estado del objeto especial
        if (shadowSpecialGameObject != null)
        {
            if (shadowSpecialGameObject.activeSelf != desiredSpecialState)
            {
                shadowSpecialGameObject.SetActive(desiredSpecialState);
            }
        }
    }
}