using UnityEngine;
using TMPro;

public class GAMESYSTEM : MonoBehaviour
{
    [Header("Referencias UI")]
    [Tooltip("Arrastra aqu� el componente TextMeshProUGUI que mostrar� el contador.")]
    [SerializeField] private TextMeshProUGUI rupiaText;

    [Header("Configuraci�n")]
    [Tooltip("N�mero m�ximo de elementos necesarios para activar los objetos.")]
    [SerializeField] private int elementosConter = 10;

    [Header("GameObjects a Activar")]
    [SerializeField] private GameObject zonaWIN;
    [SerializeField] private GameObject segundoGameObject;

    private int rupiasActuales = 0;

    private void Start()
    {
        rupiasActuales = 0;
        ActualizarTexto();
        ActualizarEstadoObjetos();
    }

    /// <summary>
    /// Suma rupias al contador.
    /// </summary>
    public void Rupia(int cantidad)
    {
        rupiasActuales += cantidad;
        ActualizarTexto();
        ActualizarEstadoObjetos();
    }

    /// <summary>
    /// Reinicia el contador a cero.
    /// </summary>
    public void ReiniciarContador()
    {
        rupiasActuales = 0;
        ActualizarTexto();
        ActualizarEstadoObjetos();
    }

    private void ActualizarTexto()
    {
        if (rupiaText != null)
        {
            rupiaText.text = rupiasActuales.ToString();
        }
    }

    private void ActualizarEstadoObjetos()
    {
        // Se activan cuando la cantidad es igual o mayor al m�ximo establecido.
        bool condicionAlcanzada = (rupiasActuales >= elementosConter);

        if (zonaWIN != null)
        {
            zonaWIN.SetActive(condicionAlcanzada);
        }

        if (segundoGameObject != null)
        {
            segundoGameObject.SetActive(condicionAlcanzada);
        }
    }
}