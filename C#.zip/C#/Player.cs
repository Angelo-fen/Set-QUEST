using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Player : MonoBehaviour
{
    [Header("Objetos desactivables (se apagan 1 por 1)")]
    [SerializeField] private GameObject[] desactivables;
    [SerializeField] private GameObject special;

    [Header("Botones del Canvas (Arrastrar desde jerarqu�a)")]
    [SerializeField] private Button boton1;
    [SerializeField] private Button boton2;
    [SerializeField] private Button boton3;
    [SerializeField] private Button boton4;

    [Header("Referencias generales")]
    [SerializeField] private GameObject Base;
    [SerializeField] private Camera mainCamera;
    [SerializeField] private GameObject Idle;
    [SerializeField, Tooltip("CapsuleCollider usado para comprobar colisiones al moverse")]
    private CapsuleCollider movementCollider;

    [Header("Configuraci�n de movimiento y rotaci�n")]
    [SerializeField] private float velocidadDesplazamiento = 5f;
    [SerializeField, Tooltip("Velocidad de suavizado para la rotaci�n (mayor = m�s r�pido)")]
    private float velocidadRotacion = 8f;
    [SerializeField, Tooltip("Margen extra para la comprobaci�n de colisiones (evita pegarse)")]
    private float collisionMargin = 0.02f;
    [SerializeField, Tooltip("M�scara de capas para considerar como obst�culos (por defecto Everything)")]
    private LayerMask obstacleMask = ~0;

    private bool boton1Activo = false;
    private bool boton2Activo = false;
    private bool boton3Activo = false;
    private bool boton4Activo = false;

    private bool rotando180 = false;
    private Quaternion rotacionObjetivo;
    private Transform baseTransform;
    private Transform camTransform;

    private int siguienteIndiceDesactivable = 0;

    void Start()
    {
        baseTransform = Base != null ? Base.transform : null;
        camTransform = mainCamera != null ? mainCamera.transform : null;

        // Inicializar objetos
        if (desactivables != null)
        {
            for (int i = 0; i < desactivables.Length; i++)
            {
                if (desactivables[i] != null)
                    desactivables[i].SetActive(true);
            }
        }

        SetActiveIfNeeded(special, false);
        SetActiveIfNeeded(Idle, true);

        ConfigurarEventosBoton(boton1, 1);
        ConfigurarEventosBoton(boton2, 2);
        ConfigurarEventosBoton(boton3, 3);
        ConfigurarEventosBoton(boton4, 4);

        if (Base == null) Debug.LogError("�Falta asignar el objeto Base!");
        if (mainCamera == null) Debug.LogError("�Falta asignar la Main Camera!");
        if (movementCollider == null) Debug.LogWarning("No se ha asignado movementCollider. La comprobaci�n de colisiones no funcionar� hasta asignarlo.");

        // Comprobaci�n adicional al iniciar: si todos los desactivables ya est�n apagados, activar special.
        RevisarSpecial();
    }

    void ConfigurarEventosBoton(Button boton, int idBoton)
    {
        if (boton == null) return;

        EventTrigger trigger = boton.GetComponent<EventTrigger>();
        if (trigger == null) trigger = boton.gameObject.AddComponent<EventTrigger>();

        EventTrigger.Entry down = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
        down.callback.AddListener((data) => { AlPresionar(idBoton); });
        trigger.triggers.Add(down);

        EventTrigger.Entry up = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
        up.callback.AddListener((data) => { AlSoltar(idBoton); });
        trigger.triggers.Add(up);

        EventTrigger.Entry exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
        exit.callback.AddListener((data) => { AlSoltar(idBoton); });
        trigger.triggers.Add(exit);
    }

    // Llama a este m�todo cada vez que quieras apagar uno m�s
    public void DesactivarUno()
    {
        if (desactivables == null || desactivables.Length == 0)
        {
            RevisarSpecial();
            return;
        }

        if (siguienteIndiceDesactivable < desactivables.Length)
        {
            if (desactivables[siguienteIndiceDesactivable] != null)
                desactivables[siguienteIndiceDesactivable].SetActive(false);

            siguienteIndiceDesactivable++;
        }

        RevisarSpecial();
    }

    private void RevisarSpecial()
    {
        bool quedaAlgunoActivo = false;

        if (desactivables != null)
        {
            for (int i = 0; i < desactivables.Length; i++)
            {
                if (desactivables[i] != null && desactivables[i].activeSelf)
                {
                    quedaAlgunoActivo = true;
                    break;
                }
            }
        }

        if (!quedaAlgunoActivo)
            SetActiveIfNeeded(special, true);
    }

    void AlPresionar(int idBoton)
    {
        SetActiveIfNeeded(Idle, false);

        if (idBoton == 1)
        {
            ActivarSolo(1);
            if (baseTransform != null && camTransform != null)
            {
                Vector3 away = baseTransform.position - camTransform.position;
                away.y = 0f;

                if (away.sqrMagnitude > 0.0001f)
                {
                    rotacionObjetivo = Quaternion.LookRotation(away.normalized, Vector3.up);
                    rotando180 = true;
                }
                else
                {
                    Vector3 fallback = -camTransform.forward;
                    fallback.y = 0f;
                    if (fallback.sqrMagnitude > 0.0001f)
                    {
                        rotacionObjetivo = Quaternion.LookRotation(fallback.normalized, Vector3.up);
                        rotando180 = true;
                    }
                }
            }
        }
        else if (idBoton == 2) ActivarSolo(2);
        else if (idBoton == 3) ActivarSolo(3);
        else if (idBoton == 4) ActivarSolo(4);
    }

    void AlSoltar(int idBoton)
    {
        if (idBoton == 1)
        {
            if (boton1Activo)
            {
                boton1Activo = false;
            }
        }
        else if (idBoton == 2)
        {
            if (boton2Activo)
            {
                boton2Activo = false;
            }
        }
        else if (idBoton == 3)
        {
            if (boton3Activo)
            {
                boton3Activo = false;
            }
        }
        else if (idBoton == 4)
        {
            if (boton4Activo)
            {
                boton4Activo = false;
            }
        }

        if (!boton1Activo && !boton2Activo && !boton3Activo && !boton4Activo)
        {
            SetActiveIfNeeded(Idle, true);
        }
    }

    void ActivarSolo(int idBoton)
    {
        boton1Activo = boton2Activo = boton3Activo = boton4Activo = false;

        if (idBoton == 1) boton1Activo = true;
        else if (idBoton == 2) boton2Activo = true;
        else if (idBoton == 3) boton3Activo = true;
        else if (idBoton == 4) boton4Activo = true;
    }

    private void SetActiveIfNeeded(GameObject go, bool estado)
    {
        if (go == null) return;
        if (go.activeSelf != estado) go.SetActive(estado);
    }

    void Update()
    {
        if (baseTransform == null || camTransform == null) return;

        if (rotando180)
        {
            baseTransform.rotation = Quaternion.Slerp(baseTransform.rotation, rotacionObjetivo, velocidadRotacion * Time.deltaTime);
            if (Quaternion.Angle(baseTransform.rotation, rotacionObjetivo) < 0.5f)
            {
                baseTransform.rotation = rotacionObjetivo;
                rotando180 = false;
            }
        }

        if (boton1Activo)
        {
            Vector3 haciaCam = camTransform.position - baseTransform.position;
            haciaCam.y = 0f;
            if (haciaCam.sqrMagnitude > 0.0001f)
            {
                Vector3 dirNorm = haciaCam.normalized;
                Vector3 desplazamiento = -dirNorm * velocidadDesplazamiento * Time.deltaTime;

                if (CanMove(desplazamiento))
                    baseTransform.Translate(desplazamiento, Space.World);

                if (!rotando180)
                {
                    Quaternion objetivo = Quaternion.LookRotation(-haciaCam, Vector3.up);
                    baseTransform.rotation = Quaternion.Slerp(baseTransform.rotation, objetivo, velocidadRotacion * Time.deltaTime);
                }
            }
        }

        if (boton2Activo)
        {
            Vector3 haciaCam = camTransform.position - baseTransform.position;
            haciaCam.y = 0f;
            if (haciaCam.sqrMagnitude > 0.0001f)
            {
                Vector3 dirNorm = haciaCam.normalized;
                Vector3 desplazamiento = dirNorm * velocidadDesplazamiento * Time.deltaTime;

                if (CanMove(desplazamiento))
                    baseTransform.Translate(desplazamiento, Space.World);

                if (!rotando180)
                {
                    Quaternion objetivo = Quaternion.LookRotation(haciaCam, Vector3.up);
                    baseTransform.rotation = Quaternion.Slerp(baseTransform.rotation, objetivo, velocidadRotacion * Time.deltaTime);
                }
            }
        }

        if (boton3Activo)
        {
            Vector3 derecha = camTransform.right;
            derecha.y = 0f;
            if (derecha.sqrMagnitude > 0.0001f)
            {
                Vector3 dirNorm = derecha.normalized;
                Vector3 desplazamiento = dirNorm * velocidadDesplazamiento * Time.deltaTime;

                if (CanMove(desplazamiento))
                    baseTransform.Translate(desplazamiento, Space.World);

                if (!rotando180)
                {
                    Quaternion objetivo = Quaternion.LookRotation(dirNorm, Vector3.up);
                    baseTransform.rotation = Quaternion.Slerp(baseTransform.rotation, objetivo, velocidadRotacion * Time.deltaTime);
                }
            }
        }

        if (boton4Activo)
        {
            Vector3 izquierda = -camTransform.right;
            izquierda.y = 0f;
            if (izquierda.sqrMagnitude > 0.0001f)
            {
                Vector3 dirNorm = izquierda.normalized;
                Vector3 desplazamiento = dirNorm * velocidadDesplazamiento * Time.deltaTime;

                if (CanMove(desplazamiento))
                    baseTransform.Translate(desplazamiento, Space.World);

                if (!rotando180)
                {
                    Quaternion objetivo = Quaternion.LookRotation(dirNorm, Vector3.up);
                    baseTransform.rotation = Quaternion.Slerp(baseTransform.rotation, objetivo, velocidadRotacion * Time.deltaTime);
                }
            }
        }
    }

    private bool CanMove(Vector3 desplazamiento)
    {
        if (movementCollider == null || baseTransform == null) return true;

        Vector3 centerWorld = movementCollider.transform.TransformPoint(movementCollider.center);
        float radius = movementCollider.radius * Mathf.Max(
            movementCollider.transform.lossyScale.x,
            movementCollider.transform.lossyScale.z);
        float height = movementCollider.height * movementCollider.transform.lossyScale.y;

        float halfHeight = Mathf.Max(0f, (height * 0.5f) - radius);

        Vector3 up = movementCollider.transform.up;
        Vector3 pointA = centerWorld + up * halfHeight;
        Vector3 pointB = centerWorld - up * halfHeight;

        float distancia = desplazamiento.magnitude + collisionMargin;

        if (distancia <= Mathf.Epsilon) return true;

        if (Physics.CapsuleCast(pointA, pointB, radius, desplazamiento.normalized, out RaycastHit hit, distancia, obstacleMask, QueryTriggerInteraction.Ignore))
        {
            return false;
        }

        return true;
    }
}
