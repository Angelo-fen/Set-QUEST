using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class ZoneTO : MonoBehaviour
{
    [Tooltip("Collider que funcionar� como trigger. Si se deja vac�o, se usar� el Collider del mismo GameObject.")]
    public Collider triggerCollider;

    [Tooltip("Collider del objeto que debe activar la zona (por ejemplo el jugador). Si se deja vac�o, cualquier collider activar� el bot�n.")]
    public Collider expectedCollider;

    [Tooltip("El Button de la escena que se activar�/desactivar�. Se usa SetActive en su GameObject.")]
    public Button targetButton;

    void Awake()
    {
        // Si no se asign�, usar el collider del mismo GameObject
        if (triggerCollider == null)
        {
            triggerCollider = GetComponent<Collider>();
        }

        if (triggerCollider == null)
        {
            Debug.LogError("[ZoneTO] No hay Collider asignado ni en el mismo GameObject ni en el campo Trigger Collider.");
            enabled = false;
            return;
        }

        // Asegurarse de que sea trigger
        if (!triggerCollider.isTrigger)
        {
            Debug.LogWarning("[ZoneTO] El Collider asignado no est� marcado como Is Trigger. Marcando isTrigger = true autom�ticamente.");
            triggerCollider.isTrigger = true;
        }

        // A�adir o configurar el Relay para recibir eventos de trigger aunque el script est� en otro GameObject
        var relay = triggerCollider.gameObject.GetComponent<TriggerRelay>();
        if (relay == null)
        {
            relay = triggerCollider.gameObject.AddComponent<TriggerRelay>();
        }
        relay.owner = this;
    }

    void Start()
    {
        if (targetButton != null)
        {
            // Apagar por defecto en escena
            targetButton.gameObject.SetActive(false);
        }
    }

    // Llamado por TriggerRelay
    internal void OnRelayEnter(Collider other)
    {
        if (targetButton == null) return;

        if (expectedCollider == null || other == expectedCollider)
        {
            targetButton.gameObject.SetActive(true);
        }
    }

    // Llamado por TriggerRelay
    internal void OnRelayExit(Collider other)
    {
        if (targetButton == null) return;

        if (expectedCollider == null || other == expectedCollider)
        {
            targetButton.gameObject.SetActive(false);
        }
    }

    // Clase auxiliar que reenv�a los eventos OnTriggerEnter/Exit al ZoneTO
    // Se a�ade autom�ticamente al GameObject que contiene el triggerCollider
    class TriggerRelay : MonoBehaviour
    {
        internal ZoneTO owner;

        void OnTriggerEnter(Collider other)
        {
            if (owner != null) owner.OnRelayEnter(other);
        }

        void OnTriggerExit(Collider other)
        {
            if (owner != null) owner.OnRelayExit(other);
        }
    }
}
