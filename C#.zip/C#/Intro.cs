using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Intro : MonoBehaviour
{
    [Header("Image y tiempos")]
    [SerializeField, Tooltip("Image UI cuya transparencia se modificar�")]
    private Image introImage;

    [SerializeField, Tooltip("Segundos para llegar al 50% de transparencia (desde el valor inicial)")]
    private float timeToHalf = 3f;

    [SerializeField, Tooltip("Segundos para pasar del 50% al 100%")]
    private float timeToFull = 1f;

    [Header("Escalado (relativo a la escala original)")]
    [SerializeField, Tooltip("Porcentaje de la escala original al iniciar (0.8 = 80%)")]
    private float startScalePercent = 0.8f;

    [SerializeField, Tooltip("Segundos para crecer desde startScalePercent hasta la escala original")]
    private float growDuration = 2f;

    [Header("Desactivaci�n de objetos")]
    [SerializeField, Tooltip("Segundos tras los cuales se desactivan los objetos listados (independiente de la animaci�n)")]
    private float deactivateAfterSeconds = 5f;

    [SerializeField, Tooltip("Lista de GameObjects que se desactivar�n tras deactivateAfterSeconds")]
    private GameObject[] objectsToDeactivate;

    [Header("Opciones")]
    [SerializeField, Tooltip("Si est� activo, la secuencia comienza autom�ticamente en Start")]
    private bool autoStart = true;

    // Estado interno
    private Coroutine introCoroutine;
    private Coroutine deactivateCoroutine;
    private Coroutine scaleCoroutine;

    // Guardar la escala original del RectTransform
    private Vector3 originalScale = Vector3.one;

    void Start()
    {
        if (introImage != null)
        {
            RectTransform rt = introImage.rectTransform;
            if (rt != null)
            {
                // Detectar y guardar escala original
                originalScale = rt.localScale;
                // Aplicar escala inicial relativa a la original
                rt.localScale = originalScale * Mathf.Max(0f, startScalePercent);
            }
        }

        if (autoStart)
        {
            StartIntro();
        }
    }

    /// <summary>
    /// Inicia la secuencia de fade y la rutina de desactivaci�n.
    /// </summary>
    public void StartIntro()
    {
        // Evitar m�ltiples inicios
        if (introCoroutine != null) StopCoroutine(introCoroutine);
        if (deactivateCoroutine != null) StopCoroutine(deactivateCoroutine);
        if (scaleCoroutine != null) StopCoroutine(scaleCoroutine);

        // Asegurar escala inicial antes de comenzar (por si se llam� manualmente)
        if (introImage != null)
        {
            RectTransform rt = introImage.rectTransform;
            if (rt != null)
            {
                rt.localScale = originalScale * Mathf.Max(0f, startScalePercent);
                scaleCoroutine = StartCoroutine(ScaleSequence());
            }
        }

        introCoroutine = StartCoroutine(FadeSequence());
        deactivateCoroutine = StartCoroutine(DeactivateAfterDelay());
    }

    /// <summary>
    /// Resetea la imagen a su alfa inicial y escala inicial y detiene las coroutines.
    /// </summary>
    public void ResetIntro()
    {
        if (introCoroutine != null) StopCoroutine(introCoroutine);
        if (deactivateCoroutine != null) StopCoroutine(deactivateCoroutine);
        if (scaleCoroutine != null) StopCoroutine(scaleCoroutine);
        introCoroutine = null;
        deactivateCoroutine = null;
        scaleCoroutine = null;

        if (introImage != null)
        {
            Color c = introImage.color;
            c.a = 0f;
            introImage.color = c;

            // Restaurar a la escala inicial relativa (80% de la original por defecto)
            RectTransform rt = introImage.rectTransform;
            if (rt != null)
            {
                rt.localScale = originalScale * Mathf.Max(0f, startScalePercent);
            }
        }
    }

    private IEnumerator FadeSequence()
    {
        if (introImage == null)
        {
            yield break;
        }

        // Guardar color inicial
        Color startColor = introImage.color;
        float startAlpha = startColor.a;

        // Primera fase: de startAlpha a 0.5
        float targetHalf = Mathf.Clamp01(0.5f);
        float elapsed = 0f;
        float durationHalf = Mathf.Max(0.0001f, timeToHalf);

        while (elapsed < durationHalf)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / durationHalf);
            float a = Mathf.Lerp(startAlpha, targetHalf, t);
            Color c = introImage.color;
            c.a = a;
            introImage.color = c;
            yield return null;
        }

        // Asegurar 50%
        {
            Color c = introImage.color;
            c.a = targetHalf;
            introImage.color = c;
        }

        // Segunda fase: de 50% a 100% (1.0) en timeToFull segundos
        float durationFull = Mathf.Max(0.0001f, timeToFull);
        elapsed = 0f;
        float startHalfAlpha = targetHalf;
        float targetFull = 1f;

        while (elapsed < durationFull)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / durationFull);
            float a = Mathf.Lerp(startHalfAlpha, targetFull, t);
            Color c = introImage.color;
            c.a = a;
            introImage.color = c;
            yield return null;
        }

        // Asegurar 100%
        {
            Color c = introImage.color;
            c.a = targetFull;
            introImage.color = c;
        }

        introCoroutine = null;
    }

    private IEnumerator ScaleSequence()
    {
        if (introImage == null)
        {
            yield break;
        }

        RectTransform rt = introImage.rectTransform;
        if (rt == null)
        {
            yield break;
        }

        float duration = Mathf.Max(0.0001f, growDuration);
        float elapsed = 0f;
        Vector3 from = originalScale * Mathf.Max(0f, startScalePercent);
        Vector3 to = originalScale;

        // Asegurar escala inicial
        rt.localScale = from;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            // Interpolaci�n lineal; sustituye por easing si lo deseas
            rt.localScale = Vector3.Lerp(from, to, t);
            yield return null;
        }

        // Asegurar escala final
        rt.localScale = to;
        scaleCoroutine = null;
    }

    private IEnumerator DeactivateAfterDelay()
    {
        float delay = Mathf.Max(0f, deactivateAfterSeconds);
        yield return new WaitForSeconds(delay);

        if (objectsToDeactivate != null)
        {
            for (int i = 0; i < objectsToDeactivate.Length; i++)
            {
                GameObject go = objectsToDeactivate[i];
                if (go != null)
                {
                    go.SetActive(false);
                }
            }
        }

        deactivateCoroutine = null;
    }

    // Nota: SetImageScale ya no es necesario porque usamos originalScale como referencia.
}
