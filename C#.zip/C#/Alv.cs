using UnityEngine;

public class Alv : MonoBehaviour
{
    [Header("Objeto que se sincronizar�")]
    [SerializeField] private GameObject objeto1;

    [Header("Objeto especial")]
    [SerializeField] private GameObject objetoEspecial;

    private void Update()
    {
        if (objeto1 == null || objetoEspecial == null)
            return;

        // Si el especial est� activo, activa el otro
        if (objeto1.activeSelf != objetoEspecial.activeInHierarchy)
        {
            objeto1.SetActive(objetoEspecial.activeInHierarchy);
        }
    }
}