using System.Collections;
using UnityEngine;
using TMPro;

public class Takerupi : MonoBehaviour
{
    [Header("Configuraci�n")]
    [Tooltip("Array de GameObjects a activar en Reset")]
    public GameObject[] objetos;

    [Tooltip("Referencia al TextMeshProUGUI principal")]
    public TextMeshProUGUI tmpContador;

    [Tooltip("Referencia al TextMeshProUGUI sombra")]
    public TextMeshProUGUI tmpSombra;

    [Tooltip("Si se deja vac�o mostrar� el mismo n�mero que el contador")]
    public string textoFijoSombra = "";

    [Tooltip("Duraci�n del Fade In")]
    public float duracionFadeIn = 1f;

    [Tooltip("Tiempo visible")]
    public float duracionHold = 2f;

    [Tooltip("Duraci�n del Fade Out")]
    public float duracionFadeOut = 1f;

    private int contador = 0;
    private Coroutine coroutineFade;

    private void Start()
    {
        contador = 0;

        if (tmpContador != null)
        {
            tmpContador.text = "0";

            Color c = tmpContador.color;
            c.a = 0f;
            tmpContador.color = c;
        }

        if (tmpSombra != null)
        {
            tmpSombra.text = string.IsNullOrEmpty(textoFijoSombra)
                ? "0"
                : textoFijoSombra;

            Color c = tmpSombra.color;
            c.a = 0f;
            tmpSombra.color = c;
        }
    }

    private void LateUpdate()
    {
        if (contador < 0)
            contador = 0;

        string valor = contador.ToString();

        if (tmpContador != null && tmpContador.text != valor)
            tmpContador.text = valor;

        if (tmpSombra != null)
        {
            string valorSombra = string.IsNullOrEmpty(textoFijoSombra)
                ? valor
                : textoFijoSombra;

            if (tmpSombra.text != valorSombra)
                tmpSombra.text = valorSombra;
        }
    }

    public void sumar(int valor)
    {
        if (!gameObject.activeInHierarchy)
            return;

        contador += valor;
        contador = Mathf.Max(0, contador);

        ActualizarTexto();

        if (coroutineFade != null)
            StopCoroutine(coroutineFade);

        coroutineFade = StartCoroutine(FadeInHoldOut());
    }

    public void restar(int valor)
    {
        if (!gameObject.activeInHierarchy)
            return;

        contador -= valor;
        contador = Mathf.Max(0, contador);

        ActualizarTexto();

        if (coroutineFade != null)
            StopCoroutine(coroutineFade);

        coroutineFade = StartCoroutine(FadeInHoldOut());
    }

    public void reiniciar()
    {
        contador = 0;

        StopAllCoroutines();
        coroutineFade = null;

        if (tmpContador != null)
        {
            tmpContador.text = "0";

            Color c = tmpContador.color;
            c.a = 0f;
            tmpContador.color = c;
        }

        if (tmpSombra != null)
        {
            tmpSombra.text = string.IsNullOrEmpty(textoFijoSombra)
                ? "0"
                : textoFijoSombra;

            Color c = tmpSombra.color;
            c.a = 0f;
            tmpSombra.color = c;
        }

        if (objetos != null)
        {
            foreach (GameObject go in objetos)
            {
                if (go != null)
                    go.SetActive(true);
            }
        }
    }

    public void reset()
    {
        reiniciar();
    }

    private void ActualizarTexto()
    {
        string valor = Mathf.Max(0, contador).ToString();

        if (tmpContador != null)
            tmpContador.text = valor;

        if (tmpSombra != null)
        {
            tmpSombra.text = string.IsNullOrEmpty(textoFijoSombra)
                ? valor
                : textoFijoSombra;
        }
    }

    private IEnumerator FadeInHoldOut()
    {
        if (tmpContador == null)
            yield break;

        float t = 0f;

        Color cMain = tmpContador.color;
        Color cShadow = tmpSombra != null ? tmpSombra.color : cMain;

        while (t < duracionFadeIn)
        {
            t += Time.deltaTime;

            float alpha = Mathf.Lerp(0f, 1f, t / duracionFadeIn);

            cMain.a = alpha;
            tmpContador.color = cMain;

            if (tmpSombra != null)
            {
                cShadow.a = alpha;
                tmpSombra.color = cShadow;
            }

            yield return null;
        }

        cMain.a = 1f;
        tmpContador.color = cMain;

        if (tmpSombra != null)
        {
            cShadow.a = 1f;
            tmpSombra.color = cShadow;
        }

        yield return new WaitForSeconds(duracionHold);

        t = 0f;

        while (t < duracionFadeOut)
        {
            t += Time.deltaTime;

            float alpha = Mathf.Lerp(1f, 0f, t / duracionFadeOut);

            cMain.a = alpha;
            tmpContador.color = cMain;

            if (tmpSombra != null)
            {
                cShadow.a = alpha;
                tmpSombra.color = cShadow;
            }

            yield return null;
        }

        cMain.a = 0f;
        tmpContador.color = cMain;

        if (tmpSombra != null)
        {
            cShadow.a = 0f;
            tmpSombra.color = cShadow;
        }

        coroutineFade = null;
    }
}