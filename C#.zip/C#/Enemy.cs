using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class Enemy : MonoBehaviour
{
    [Header("Referencias")]
    [Tooltip("GameObject que representa la c�psula del enemigo. Su frente mirar� al player.")]
    public GameObject enemyCapsule;

    [Tooltip("Transform del jugador que el enemigo perseguir�.")]
    public Transform player;

    [Tooltip("Collider trigger que representa la zona mala (debe tener Is Trigger = true).")]
    public Collider zonaMala;

    [Header("Movimiento")]
    [Tooltip("Velocidad base de movimiento del enemigo en m/s.")]
    public float speed = 3.5f;

    [Tooltip("Velocidad de rotaci�n de la c�psula en grados por segundo.")]
    public float rotationSpeed = 720f;

    [Tooltip("Distancia m�nima para detenerse.")]
    public float stoppingDistance = 0.2f;

    [Tooltip("L�mite m�ximo de velocidad (0 = sin l�mite).")]
    public float maxSpeed = 0f;

    [Header("Vidas (objetos a desactivar en zona mala)")]
    [Tooltip("Primer GameObject (vida 1).")]
    public GameObject obj1;

    [Tooltip("Segundo GameObject (vida 2).")]
    public GameObject obj2;

    [Tooltip("Tercer GameObject (vida 3).")]
    public GameObject obj3;

    [Tooltip("GameObject especial que se activar� cuando las 3 vidas est�n desactivadas.")]
    public GameObject specialObject;

    [Header("Vidas array (opcional)")]
    [Tooltip("Array opcional de vidas. Si est� vac�o, se usar� obj1, obj2, obj3 en ese orden.")]
    public GameObject[] vidas;

    [Header("Tiempos ajustables")]
    [Tooltip("Tiempo en segundos entre cada desactivaci�n de vida mientras el enemigo est� en la zona mala.")]
    [Min(0f)]
    public float lifeLossInterval = 1f;

    [Tooltip("Tiempo en segundos que espera antes de reanudar la persecuci�n al salir de la zona mala.")]
    [Min(0f)]
    public float resumeDelay = 1f;

    private NavMeshAgent agent;

    // Estado zona mala
    private bool isInZonaMala = false;
    private Coroutine deactivationCoroutine = null;
    private Coroutine resumeCoroutine = null;

    // Indicador de esperas
    private bool waitingToResume = false;
    private int nextDeactivateIndex = 0;

    // Cach� para optimizar paredes (Evita buscar en Update masivamente)
    private float wallCheckTimer = 0f;
    private const float wallCheckInterval = 0.5f;

    void Awake()
    {
        InitializeAgent();
    }

    private void InitializeAgent()
    {
        if (agent == null)
        {
            agent = GetComponent<NavMeshAgent>();
        }

        if (agent == null)
        {
            Debug.LogError("NavMeshAgent no encontrado en Enemy.", this);
            enabled = false;
            return;
        }

        // Configuraci�n robusta del agente
        agent.speed = Mathf.Max(0f, speed);
        agent.stoppingDistance = Mathf.Max(0.05f, stoppingDistance);
        agent.angularSpeed = 500f;
        agent.acceleration = 28f;

        agent.autoBraking = false;
        agent.obstacleAvoidanceType = ObstacleAvoidanceType.LowQualityObstacleAvoidance;
        agent.avoidancePriority = 50;

        agent.updateRotation = false; // Control manual de rotaci�n
        agent.updateUpAxis = true;

        if (zonaMala != null && !zonaMala.isTrigger)
            Debug.LogWarning("zonaMala debe tener 'Is Trigger' activado.", zonaMala);

        if (vidas == null || vidas.Length == 0)
        {
            vidas = new GameObject[] { obj1, obj2, obj3 };
        }

        nextDeactivateIndex = GetNextActiveIndex();

        lifeLossInterval = Mathf.Max(0f, lifeLossInterval);
        resumeDelay = Mathf.Max(0f, resumeDelay);
    }

    void OnDisable()
    {
        StopAllCoroutines();
        deactivationCoroutine = null;
        resumeCoroutine = null;
    }

    void Update()
    {
        if (player == null) return;

        // Optimizaci�n: Comprobaci�n de paredes temporizada
        wallCheckTimer += Time.deltaTime;
        if (wallCheckTimer >= wallCheckInterval)
        {
            wallCheckTimer = 0f;
            IgnoreWallsOptimized();
        }

        EnsureAgentOnNavMesh();

        // Sincronizar velocidad de forma din�mica
        float targetSpeed = Mathf.Max(0f, speed);
        if (maxSpeed > 0f) targetSpeed = Mathf.Min(targetSpeed, maxSpeed);
        if (agent != null && Mathf.Abs(agent.speed - targetSpeed) > 0.01f)
            agent.speed = targetSpeed;

        // Gesti�n de persecuci�n
        if (!isInZonaMala && !waitingToResume)
        {
            if (agent != null && agent.enabled)
            {
                if (agent.isStopped) agent.isStopped = false;
                SetRobustDestination(player.position);
            }
        }
        else
        {
            if (agent != null && agent.enabled && !agent.isStopped)
                agent.isStopped = true;
        }

        RotateCapsuleTowardsPlayer();
    }

    private void IgnoreWallsOptimized()
    {
        GameObject[] walls = GameObject.FindGameObjectsWithTag("pared");
        if (walls.Length == 0) return;

        Collider[] myColliders = GetComponentsInChildren<Collider>();
        if (myColliders.Length == 0) return;

        foreach (GameObject wall in walls)
        {
            if (wall == null) continue;
            Collider[] wallColliders = wall.GetComponentsInChildren<Collider>();

            foreach (Collider myCol in myColliders)
            {
                if (myCol == null) continue;
                foreach (Collider wallCol in wallColliders)
                {
                    if (wallCol != null)
                    {
                        Physics.IgnoreCollision(myCol, wallCol, true);
                    }
                }
            }
        }
    }

    private void SetRobustDestination(Vector3 targetPosition)
    {
        if (agent == null || !agent.enabled || !agent.isOnNavMesh) return;

        NavMeshHit hit;
        if (NavMesh.SamplePosition(targetPosition, out hit, 3.0f, NavMesh.AllAreas))
        {
            agent.SetDestination(hit.position);
        }
        else
        {
            agent.SetDestination(targetPosition);
        }
    }

    private void EnsureAgentOnNavMesh()
    {
        if (agent == null || !agent.enabled) return;

        if (!agent.isOnNavMesh)
        {
            NavMeshHit hit;
            if (NavMesh.SamplePosition(transform.position, out hit, 2.0f, NavMesh.AllAreas))
            {
                agent.Warp(hit.position);
            }
        }
    }

    private void RotateCapsuleTowardsPlayer()
    {
        if (enemyCapsule == null || player == null) return;

        Vector3 direction = player.position - enemyCapsule.transform.position;
        direction.y = 0f;

        if (direction.sqrMagnitude < 0.0001f) return;

        Quaternion targetRot = Quaternion.LookRotation(direction.normalized);
        enemyCapsule.transform.rotation = Quaternion.RotateTowards(
            enemyCapsule.transform.rotation,
            targetRot,
            rotationSpeed * Time.deltaTime
        );
    }

    public void sumar(int cantidad)
    {
        speed += cantidad;
        if (speed < 0f) speed = 0f;
        if (maxSpeed > 0f) speed = Mathf.Min(speed, maxSpeed);
        if (agent != null) agent.speed = Mathf.Max(0f, speed);
        Debug.Log($"Enemy sumar llamado. Nueva velocidad: {speed}", this);
    }

    public void ReiniciarPersecucion()
    {
        // 1. Forzar activaci�n del GameObject si estaba apagado
        if (!gameObject.activeSelf)
        {
            gameObject.SetActive(true);
        }

        // 2. Detener corrutinas previas
        if (deactivationCoroutine != null)
        {
            StopCoroutine(deactivationCoroutine);
            deactivationCoroutine = null;
        }

        if (resumeCoroutine != null)
        {
            StopCoroutine(resumeCoroutine);
            resumeCoroutine = null;
        }

        isInZonaMala = false;
        waitingToResume = false;

        // 3. Reactivar todas las vidas
        if (vidas != null)
        {
            foreach (GameObject vida in vidas)
            {
                if (vida != null) vida.SetActive(true);
            }
        }

        if (specialObject != null)
            specialObject.SetActive(false);

        nextDeactivateIndex = 0;

        // 4. Asegurar referencia y estado del NavMeshAgent
        if (agent == null)
        {
            agent = GetComponent<NavMeshAgent>();
        }

        if (agent != null)
        {
            if (!agent.isOnNavMesh)
            {
                NavMeshHit hit;
                if (NavMesh.SamplePosition(transform.position, out hit, 3.0f, NavMesh.AllAreas))
                {
                    agent.Warp(hit.position);
                }
            }

            if (agent.isOnNavMesh)
            {
                agent.isStopped = false;
                agent.ResetPath();

                if (player != null)
                    SetRobustDestination(player.position);
            }
        }

        Debug.Log("Persecuci�n reiniciada al 100% de forma robusta.", this);
    }

    public void Vida(int cantidad)
    {
        if (cantidad <= 0) return;

        int reactivadas = 0;
        for (int i = 0; i < cantidad; i++)
        {
            if (TryReactivateOne())
                reactivadas++;
            else
                break;
        }

        nextDeactivateIndex = GetNextActiveIndex();

        if (reactivadas > 0 && specialObject != null && specialObject.activeSelf)
        {
            specialObject.SetActive(false);
            Debug.Log("Enemy: specialObject desactivado por reactivaci�n de vidas.", this);
        }

        Debug.Log($"Enemy Vida llamado. Vidas reactivadas: {reactivadas}. nextDeactivateIndex ahora: {nextDeactivateIndex}", this);
    }

    private bool TryReactivateOne()
    {
        if (vidas == null || vidas.Length == 0) return false;
        for (int i = 0; i < vidas.Length; i++)
        {
            if (vidas[i] != null && !vidas[i].activeSelf)
            {
                vidas[i].SetActive(true);
                return true;
            }
        }
        return false;
    }

    private int GetNextActiveIndex()
    {
        if (vidas == null || vidas.Length == 0) return 0;
        for (int i = 0; i < vidas.Length; i++)
        {
            if (vidas[i] != null && vidas[i].activeSelf) return i;
        }
        return vidas.Length;
    }

    void OnTriggerEnter(Collider other)
    {
        if (zonaMala == null || other != zonaMala) return;

        isInZonaMala = true;
        if (agent != null && agent.isOnNavMesh) agent.isStopped = true;

        if (resumeCoroutine != null)
        {
            StopCoroutine(resumeCoroutine);
            resumeCoroutine = null;
        }

        waitingToResume = false;
        nextDeactivateIndex = GetNextActiveIndex();

        if (deactivationCoroutine == null)
        {
            deactivationCoroutine = StartCoroutine(DeactivationSequence());
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (zonaMala == null || other != zonaMala) return;

        isInZonaMala = false;

        if (deactivationCoroutine != null)
        {
            StopCoroutine(deactivationCoroutine);
            deactivationCoroutine = null;
        }

        nextDeactivateIndex = 0;

        if (resumeCoroutine != null)
        {
            StopCoroutine(resumeCoroutine);
            resumeCoroutine = null;
        }

        waitingToResume = true;
        resumeCoroutine = StartCoroutine(ResumeAfterDelay(resumeDelay));
    }

    private IEnumerator ResumeAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);

        waitingToResume = false;

        if (agent != null && agent.isOnNavMesh)
        {
            agent.isStopped = false;
            if (player != null) SetRobustDestination(player.position);
        }
        resumeCoroutine = null;
    }

    private IEnumerator DeactivationSequence()
    {
        while (isInZonaMala)
        {
            yield return new WaitForSeconds(lifeLossInterval);

            if (!isInZonaMala) break;

            int nextActive = GetNextActiveIndex();
            if (nextActive >= vidas.Length || AreAllDeactivated())
            {
                ActivateSpecialIfNeeded();
                break;
            }

            if (vidas != null && nextActive < vidas.Length)
            {
                GameObject toDisable = vidas[nextActive];
                if (toDisable != null && toDisable.activeSelf)
                {
                    toDisable.SetActive(false);
                    Debug.Log($"Enemy: vidas[{nextActive}] desactivado.", this);
                }
            }

            if (AreAllDeactivated())
            {
                ActivateSpecialIfNeeded();
                break;
            }
        }

        deactivationCoroutine = null;
    }

    private bool AreAllDeactivated()
    {
        if (vidas == null || vidas.Length == 0) return true;
        for (int i = 0; i < vidas.Length; i++)
        {
            if (vidas[i] != null && vidas[i].activeSelf) return false;
        }
        return true;
    }

    private void ActivateSpecialIfNeeded()
    {
        if (specialObject == null) return;
        if (AreAllDeactivated())
        {
            if (!specialObject.activeSelf)
            {
                specialObject.SetActive(true);
                Debug.Log("Enemy: specialObject activado por quedar sin vidas.", this);
            }
        }
    }

    public void SetPlayer(Transform newPlayer)
    {
        player = newPlayer;
    }
}