using UnityEngine;
using UnityEngine.UI;

public class Sound : MonoBehaviour
{
    [Header("Asignar en Inspector")]
    public Button btn;
    public AudioClip clip;

    void Awake()
    {
        // Intentar obtener el Button si no fue asignado
        if (btn == null)
            btn = GetComponent<Button>();

        if (btn == null)
        {
            Debug.LogWarning("Sound: Asigna un Button en el Inspector o coloca este script en el mismo GameObject que el Button.");
        }
        else
        {
            btn.onClick.AddListener(PlaySound);
        }
    }

    void OnDestroy()
    {
        if (btn != null)
            btn.onClick.RemoveListener(PlaySound);
    }

    private void PlaySound()
    {
        if (clip != null)
        {
            // Reproduce el clip en la posici�n de la c�mara principal
            AudioSource.PlayClipAtPoint(clip, Camera.main.transform.position);
        }
        else
        {
            Debug.LogWarning("Sound: No hay AudioClip asignado.");
        }
    }
}
