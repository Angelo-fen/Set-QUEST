using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Play : MonoBehaviour
{
    [Header("Objetos desactivables (se apagan 1 por 1)")]
    [SerializeField] private GameObject[] desactivables;
    [SerializeField] private GameObject special;

    [Header("Joystick UI (Arrastrar desde jerarqu�a)")]
    [Tooltip("Imagen que act�a como fondo del joystick")]
    [SerializeField] private RectTransform joystickBackground;
    [Tooltip("Imagen que act�a como handle (mover)")]
    [SerializeField] private RectTransform joystickHandle;
    [Tooltip("Rango m�ximo en p�xeles que puede moverse el handle desde el centro")]
    [SerializeField] private float joystickRange = 80f;
    [Tooltip("Si true, el joystick vuelve al centro al soltar")]
    [SerializeField] private bool recenterOnRelease = true;
    [Tooltip("Zona muerta para evitar micro-movimientos (0..1)")]
    [SerializeField, Range(0f, 0.5f)] private float deadZone = 0.1f;

    [Header("Bot�n Run (opcional)")]
    [SerializeField] private Button botonRun;

    [Header("Animator (Anime)")]
    [Tooltip("Arrastra aqu� el componente Animator del GameObject que controla las animaciones")]
    public Animator animator;
    [Tooltip("Arrastra aqu� el Animator Controller (RuntimeAnimatorController) que contiene Idle, Walk, Run")]
    public RuntimeAnimatorController animatorController;

    [Header("Referencias generales")]
    [SerializeField] private GameObject Base;
    [SerializeField] private Camera mainCamera;
    [SerializeField] private GameObject Idle;
    [SerializeField, Tooltip("CapsuleCollider usado para comprobar colisiones al moverse")]
    private CapsuleCollider movementCollider;

    [Header("Configuraci�n de movimiento y rotaci�n")]
    [SerializeField] private float velocidadDesplazamiento = 5f;
    [SerializeField, Tooltip("Velocidad de suavizado para la rotaci�n (mayor = m�s r�pido)")]
    private float velocidadRotacion = 8f;
    [SerializeField, Tooltip("Margen extra para la comprobaci�n de colisiones (evita pegarse)")]
    private float collisionMargin = 0.02f;
    [SerializeField, Tooltip("M�scara de capas para considerar como obst�culos (por defecto Everything)")]
    private LayerMask obstacleMask = ~0;

    [Header("Audio de Caminata")]
    [Tooltip("Arrastra aqu� el clip de audio para el sonido de pasos / caminata")]
    [SerializeField] private AudioClip sonidoCaminar;
    [Tooltip("Componente AudioSource (se detectar�/crear� autom�ticamente si se deja vac�o)")]
    [SerializeField] private AudioSource audioSourceCaminar;

    // Valores de Speed para Animator
    private const float IDLE_SPEED = 0f;
    private const float WALK_SPEED = 1f;
    private const float RUN_SPEED = 2f;

    // Estado interno del joystick
    private Vector2 joystickInput = Vector2.zero;
    private bool joystickPressed = false;

    // Flags de movimiento/animaci�n
    private bool walkPressed = false;
    private bool runPressed = false;

    private bool rotando180 = false;
    private Quaternion rotacionObjetivo;
    private Transform baseTransform;
    private Transform camTransform;

    private int siguienteIndiceDesactivable = 0;

    void Start()
    {
        baseTransform = Base != null ? Base.transform : null;
        camTransform = mainCamera != null ? mainCamera.transform : null;

        // Inicializar objetos
        if (desactivables != null)
        {
            for (int i = 0; i < desactivables.Length; i++)
            {
                if (desactivables[i] != null)
                    desactivables[i].SetActive(true);
            }
        }

        SetActiveIfNeeded(special, false);
        SetActiveIfNeeded(Idle, true);

        if (Base == null) Debug.LogError("�Falta asignar el objeto Base!");
        if (mainCamera == null) Debug.LogError("�Falta asignar la Main Camera!");
        if (movementCollider == null) Debug.LogWarning("No se ha asignado movementCollider. La comprobaci�n de colisiones no funcionar� hasta asignarlo.");

        // Configuraci�n autom�tica del AudioSource para caminata por seguridad
        if (audioSourceCaminar == null)
        {
            audioSourceCaminar = GetComponent<AudioSource>();
            if (audioSourceCaminar == null)
            {
                audioSourceCaminar = gameObject.AddComponent<AudioSource>();
            }
        }

        if (audioSourceCaminar != null)
        {
            audioSourceCaminar.loop = true; // Asegurar que reproduzca en bucle continuo mientras camina
        }

        // Configurar eventos del joystick si hay componentes UI asignados
        if (joystickHandle != null)
        {
            EventTrigger trigger = joystickHandle.GetComponent<EventTrigger>();
            if (trigger == null) trigger = joystickHandle.gameObject.AddComponent<EventTrigger>();

            var entryDown = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
            entryDown.callback.AddListener((data) => { OnJoystickDown((PointerEventData)data); });
            trigger.triggers.Add(entryDown);

            var entryUp = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
            entryUp.callback.AddListener((data) => { OnJoystickUp((PointerEventData)data); });
            trigger.triggers.Add(entryUp);

            var entryDrag = new EventTrigger.Entry { eventID = EventTriggerType.Drag };
            entryDrag.callback.AddListener((data) => { OnJoystickDrag((PointerEventData)data); });
            trigger.triggers.Add(entryDrag);
        }

        // Configurar evento Run si se asign� el bot�n
        if (botonRun != null)
        {
            EventTrigger runTrigger = botonRun.GetComponent<EventTrigger>();
            if (runTrigger == null) runTrigger = botonRun.gameObject.AddComponent<EventTrigger>();

            var runDown = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
            runDown.callback.AddListener((data) => { runPressed = true; });
            runTrigger.triggers.Add(runDown);

            var runUp = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
            runUp.callback.AddListener((data) => { runPressed = false; });
            runTrigger.triggers.Add(runUp);

            var runExit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
            runExit.callback.AddListener((data) => { runPressed = false; });
            runTrigger.triggers.Add(runExit);
        }

        // Aplicar Animator Controller si fue asignado
        if (animator != null && animatorController != null)
        {
            animator.runtimeAnimatorController = animatorController;
        }
        else if (animator == null)
        {
            Debug.LogWarning("Play: No hay Animator asignado.");
        }

        // Comprobaci�n adicional al iniciar: si todos los desactivables ya est�n apagados, activar special.
        RevisarSpecial();
    }

    // Llama a este m�todo cada vez que quieras apagar uno m�s
    public void DesactivarUno()
    {
        if (desactivables == null || desactivables.Length == 0)
        {
            RevisarSpecial();
            return;
        }

        if (siguienteIndiceDesactivable < desactivables.Length)
        {
            if (desactivables[siguienteIndiceDesactivable] != null)
                desactivables[siguienteIndiceDesactivable].SetActive(false);

            siguienteIndiceDesactivable++;
        }

        RevisarSpecial();
    }

    private void RevisarSpecial()
    {
        bool quedaAlgunoActivo = false;

        if (desactivables != null)
        {
            for (int i = 0; i < desactivables.Length; i++)
            {
                if (desactivables[i] != null && desactivables[i].activeSelf)
                {
                    quedaAlgunoActivo = true;
                    break;
                }
            }
        }

        if (!quedaAlgunoActivo)
            SetActiveIfNeeded(special, true);
    }

    private void OnJoystickDown(PointerEventData data)
    {
        joystickPressed = true;
        SetActiveIfNeeded(Idle, false);
        UpdateJoystickInput(data);
    }

    private void OnJoystickUp(PointerEventData data)
    {
        joystickPressed = false;
        joystickInput = Vector2.zero;
        if (recenterOnRelease && joystickHandle != null && joystickBackground != null)
        {
            joystickHandle.anchoredPosition = Vector2.zero;
        }

        // Actualizar walkPressed y Idle
        walkPressed = false;
        if (!runPressed)
            SetActiveIfNeeded(Idle, true);
    }

    private void OnJoystickDrag(PointerEventData data)
    {
        UpdateJoystickInput(data);
    }

    private void UpdateJoystickInput(PointerEventData data)
    {
        if (joystickBackground == null || joystickHandle == null) return;

        Vector2 localPoint;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(joystickBackground, data.position, data.pressEventCamera, out localPoint);

        // Clamp al rango
        Vector2 clamped = Vector2.ClampMagnitude(localPoint, joystickRange);
        joystickHandle.anchoredPosition = clamped;

        // Normalizar a -1..1 seg�n joystickRange
        joystickInput = clamped / joystickRange;

        // Aplicar dead zone
        if (joystickInput.magnitude < deadZone) joystickInput = Vector2.zero;

        // Actualizar walkPressed
        walkPressed = joystickInput.sqrMagnitude > 0f;
    }

    void Update()
    {
        if (baseTransform == null || camTransform == null) return;

        // Si se est� rotando 180 por la acci�n previa (como en el original)
        if (rotando180)
        {
            baseTransform.rotation = Quaternion.Slerp(baseTransform.rotation, rotacionObjetivo, velocidadRotacion * Time.deltaTime);
            if (Quaternion.Angle(baseTransform.rotation, rotacionObjetivo) < 0.5f)
            {
                baseTransform.rotation = rotacionObjetivo;
                rotando180 = false;
            }
        }

        // Movimiento con joystick
        if (joystickInput.sqrMagnitude > 0.0001f)
        {
            Vector3 camForward = camTransform.forward;
            camForward.y = 0f;
            camForward.Normalize();

            Vector3 camRight = camTransform.right;
            camRight.y = 0f;
            camRight.Normalize();

            Vector3 moveDir = camForward * joystickInput.y + camRight * joystickInput.x;
            if (moveDir.sqrMagnitude > 0.0001f)
            {
                float speedMultiplier = runPressed ? 1.8f : 1f; // run aumenta velocidad (ajustable)
                Vector3 desplazamiento = moveDir.normalized * velocidadDesplazamiento * speedMultiplier * Time.deltaTime;

                // Intentar mover con sliding si hay colisi�n
                AttemptMove(desplazamiento);

                // Mantener rotaci�n del player hacia donde camina (suavizado)
                if (!rotando180)
                {
                    Quaternion objetivo = Quaternion.LookRotation(moveDir, Vector3.up);
                    baseTransform.rotation = Quaternion.Slerp(baseTransform.rotation, objetivo, velocidadRotacion * Time.deltaTime);
                }
            }

            // Asegurar Idle apagado mientras haya input
            SetActiveIfNeeded(Idle, false);
        }
        else
        {
            // Si no hay input y joystick no est� presionado, volver a Idle (si no se est� corriendo)
            if (!joystickPressed && !runPressed)
            {
                SetActiveIfNeeded(Idle, true);
            }
        }

        // Actualizar Animator Speed seg�n flags
        float targetSpeed = IDLE_SPEED;
        if (runPressed)
        {
            targetSpeed = RUN_SPEED;
        }
        else if (walkPressed)
        {
            targetSpeed = WALK_SPEED;
        }
        else
        {
            targetSpeed = IDLE_SPEED;
        }
        SetSpeed(targetSpeed);

        // Control del sonido de caminata (solo suena cuando walkPressed est� activo y NO se est� corriendo)
        GestionarAudioCaminata();
    }

    /// <summary>
    /// Controla la reproducci�n y pausa del sonido de caminata en bucle.
    /// </summary>
    private void GestionarAudioCaminata()
    {
        if (audioSourceCaminar == null || sonidoCaminar == null) return;

        // Se considera caminando si walkPressed es verdadero y runPressed es falso
        bool estaCaminando = walkPressed && !runPressed;

        if (estaCaminando)
        {
            if (audioSourceCaminar.clip != sonidoCaminar)
            {
                audioSourceCaminar.clip = sonidoCaminar;
            }

            if (!audioSourceCaminar.isPlaying)
            {
                audioSourceCaminar.Play();
            }
        }
        else
        {
            if (audioSourceCaminar.isPlaying)
            {
                audioSourceCaminar.Stop();
            }
        }
    }

    /// <summary>
    /// Intenta mover la Base por 'desplazamiento'. Si hay colisi�n, calcula un vector de slide
    /// proyectando el desplazamiento sobre el plano perpendicular a la normal del impacto y
    /// mueve al personaje por ese vector si est� libre.
    /// </summary>
    private void AttemptMove(Vector3 desplazamiento)
    {
        if (movementCollider == null || baseTransform == null)
        {
            baseTransform.Translate(desplazamiento, Space.World);
            return;
        }

        // Preparar datos del capsule en mundo (igual que en CanMove)
        Vector3 centerWorld = movementCollider.transform.TransformPoint(movementCollider.center);
        float radius = movementCollider.radius * Mathf.Max(
            movementCollider.transform.lossyScale.x,
            movementCollider.transform.lossyScale.z);
        float height = movementCollider.height * movementCollider.transform.lossyScale.y;
        float halfHeight = Mathf.Max(0f, (height * 0.5f) - radius);
        Vector3 up = movementCollider.transform.up;
        Vector3 pointA = centerWorld + up * halfHeight;
        Vector3 pointB = centerWorld - up * halfHeight;

        float distancia = desplazamiento.magnitude + collisionMargin;
        if (distancia <= Mathf.Epsilon)
        {
            return;
        }

        // Primer intento: si no hay colisi�n, mover completo
        if (!Physics.CapsuleCast(pointA, pointB, radius, desplazamiento.normalized, out RaycastHit hit, distancia, obstacleMask, QueryTriggerInteraction.Ignore))
        {
            baseTransform.Translate(desplazamiento, Space.World);
            return;
        }

        // Si hay colisi�n, calcular vector de slide (proyecci�n sobre el plano del hit)
        Vector3 slide = Vector3.ProjectOnPlane(desplazamiento, hit.normal);

        // Si el slide es muy peque�o, no mover
        if (slide.magnitude <= 0.0001f) return;

        // Intentar mover por el slide (comprobando colisiones nuevamente)
        float slideDist = slide.magnitude + collisionMargin;
        if (!Physics.CapsuleCast(pointA, pointB, radius, slide.normalized, out RaycastHit hit2, slideDist, obstacleMask, QueryTriggerInteraction.Ignore))
        {
            baseTransform.Translate(slide, Space.World);
            return;
        }

        // Si el slide tambi�n choca, intentar una versi�n reducida del slide (por ejemplo, componente tangencial)
        // Esto ayuda a "resbalar" por esquinas complejas en pasos peque�os.
        Vector3 reducedSlide = slide.normalized * Mathf.Max(0f, slide.magnitude - (hit2.distance + collisionMargin));
        if (reducedSlide.magnitude > 0.0001f)
        {
            // comprobar si la peque�a correcci�n est� libre
            if (!Physics.CapsuleCast(pointA, pointB, radius, reducedSlide.normalized, out RaycastHit hit3, reducedSlide.magnitude + collisionMargin, obstacleMask, QueryTriggerInteraction.Ignore))
            {
                baseTransform.Translate(reducedSlide, Space.World);
                return;
            }
        }

        // Si todo falla, no mover (pero no bloquea futuras comprobaciones)
    }

    private bool CanMove(Vector3 desplazamiento)
    {
        if (movementCollider == null || baseTransform == null) return true;

        Vector3 centerWorld = movementCollider.transform.TransformPoint(movementCollider.center);
        float radius = movementCollider.radius * Mathf.Max(
            movementCollider.transform.lossyScale.x,
            movementCollider.transform.lossyScale.z);
        float height = movementCollider.height * movementCollider.transform.lossyScale.y;

        float halfHeight = Mathf.Max(0f, (height * 0.5f) - radius);

        Vector3 up = movementCollider.transform.up;
        Vector3 pointA = centerWorld + up * halfHeight;
        Vector3 pointB = centerWorld - up * halfHeight;

        float distancia = desplazamiento.magnitude + collisionMargin;

        if (distancia <= Mathf.Epsilon) return true;

        if (Physics.CapsuleCast(pointA, pointB, radius, desplazamiento.normalized, out RaycastHit hit, distancia, obstacleMask, QueryTriggerInteraction.Ignore))
        {
            return false;
        }

        return true;
    }

    // Funciones p�blicas para UI (compatibilidad con script A)
    public void Walk()
    {
        walkPressed = true;
        // For compatibility: simulate joystick full forward
        joystickInput = new Vector2(0f, 1f);
        if (joystickHandle != null && joystickBackground != null)
            joystickHandle.anchoredPosition = Vector2.up * joystickRange;
        SetActiveIfNeeded(Idle, false);
    }

    public void WalkRelease()
    {
        walkPressed = false;
        joystickInput = Vector2.zero;
        if (recenterOnRelease && joystickHandle != null && joystickBackground != null)
            joystickHandle.anchoredPosition = Vector2.zero;
        if (!runPressed)
            SetActiveIfNeeded(Idle, true);
    }

    public void Run()
    {
        runPressed = true;
        SetActiveIfNeeded(Idle, false);
    }

    public void RunRelease()
    {
        runPressed = false;
        if (!walkPressed && !joystickPressed)
            SetActiveIfNeeded(Idle, true);
    }

    private void SetSpeed(float value)
    {
        if (animator == null) return;
        animator.SetFloat("Speed", value);
    }

    private void SetActiveIfNeeded(GameObject go, bool estado)
    {
        if (go == null) return;
        if (go.activeSelf != estado) go.SetActive(estado);
    }
}