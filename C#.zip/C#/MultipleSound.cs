using UnityEngine;
using UnityEngine.UI;

public class MultipleSound : MonoBehaviour
{
    [Header("Botones que reproducir�n el sonido")]
    public Button[] buttons;

    [Header("Sonido a reproducir")]
    public AudioClip soundClip;

    private AudioSource audioSource;

    private void Awake()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;
        audioSource.loop = false;
    }

    private void Start()
    {
        foreach (Button btn in buttons)
        {
            if (btn != null)
            {
                btn.onClick.AddListener(PlaySound);
            }
        }
    }

    private void PlaySound()
    {
        if (soundClip != null)
        {
            audioSource.PlayOneShot(soundClip);
        }
    }

    private void OnDestroy()
    {
        foreach (Button btn in buttons)
        {
            if (btn != null)
            {
                btn.onClick.RemoveListener(PlaySound);
            }
        }
    }
}