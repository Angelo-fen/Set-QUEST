using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;

public class A : MonoBehaviour
{
    [Header("Botones del Canvas (Arrastrar desde jerarqu�a)")]
    [SerializeField] private Button boton1;
    [SerializeField] private Button boton2;
    [SerializeField] private Button boton3;
    [SerializeField] private Button boton4;
    [SerializeField, Tooltip("Bot�n que activa la carrera hacia la direcci�n de la c�mara")]
    private Button botonRun;

    [Header("Animator (Anime)")]
    [Tooltip("Arrastra aqu� el componente Animator del GameObject que controla las animaciones")]
    public Animator animator;
    [Tooltip("Arrastra aqu� el Animator Controller (RuntimeAnimatorController) que contiene Idle, Walk, Run")]
    public RuntimeAnimatorController animatorController;

    // Valores de Speed para Animator
    private const float IDLE_SPEED = 0f;
    private const float WALK_SPEED = 1f;
    private const float RUN_SPEED = 2f;

    private bool boton1Activo = false;
    private bool boton2Activo = false;
    private bool boton3Activo = false;
    private bool boton4Activo = false;

    // Flags adicionales para las funciones Walk/Run p�blicas (UI)
    private bool walkPressed = false;
    private bool runPressed = false;

    void Start()
    {
        ConfigurarEventosBoton(boton1, 1);
        ConfigurarEventosBoton(boton2, 2);
        ConfigurarEventosBoton(boton3, 3);
        ConfigurarEventosBoton(boton4, 4);
        ConfigurarEventoRun(botonRun);

        // Aplicar Animator Controller si fue asignado
        if (animator != null && animatorController != null)
        {
            animator.runtimeAnimatorController = animatorController;
        }
        else if (animator == null)
        {
            Debug.LogWarning("Anime: No hay Animator asignado.");
        }
    }

    void ConfigurarEventosBoton(Button boton, int idBoton)
    {
        if (boton == null) return;

        EventTrigger trigger = boton.GetComponent<EventTrigger>();
        if (trigger == null) trigger = boton.gameObject.AddComponent<EventTrigger>();

        EventTrigger.Entry down = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
        down.callback.AddListener((data) => { AlPresionar(idBoton); });
        trigger.triggers.Add(down);

        EventTrigger.Entry up = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
        up.callback.AddListener((data) => { AlSoltar(idBoton); });
        trigger.triggers.Add(up);

        EventTrigger.Entry exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
        exit.callback.AddListener((data) => { AlSoltar(idBoton); });
        trigger.triggers.Add(exit);
    }

    void ConfigurarEventoRun(Button runButton)
    {
        if (runButton == null) return;

        EventTrigger trigger = runButton.GetComponent<EventTrigger>();
        if (trigger == null) trigger = runButton.gameObject.AddComponent<EventTrigger>();

        EventTrigger.Entry down = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
        down.callback.AddListener((data) => { runPressed = true; });
        trigger.triggers.Add(down);

        EventTrigger.Entry up = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
        up.callback.AddListener((data) => { runPressed = false; });
        trigger.triggers.Add(up);

        EventTrigger.Entry exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
        exit.callback.AddListener((data) => { runPressed = false; });
        trigger.triggers.Add(exit);
    }

    void AlPresionar(int idBoton)
    {
        if (idBoton == 1) ActivarSolo(1);
        else if (idBoton == 2) ActivarSolo(2);
        else if (idBoton == 3) ActivarSolo(3);
        else if (idBoton == 4) ActivarSolo(4);

        // Actualizar walkPressed seg�n flags
        walkPressed = boton1Activo || boton2Activo || boton3Activo || boton4Activo;
    }

    void AlSoltar(int idBoton)
    {
        if (idBoton == 1) boton1Activo = false;
        else if (idBoton == 2) boton2Activo = false;
        else if (idBoton == 3) boton3Activo = false;
        else if (idBoton == 4) boton4Activo = false;

        // Actualizar walkPressed seg�n flags
        walkPressed = boton1Activo || boton2Activo || boton3Activo || boton4Activo;
    }

    void ActivarSolo(int idBoton)
    {
        boton1Activo = boton2Activo = boton3Activo = boton4Activo = false;

        if (idBoton == 1) boton1Activo = true;
        else if (idBoton == 2) boton2Activo = true;
        else if (idBoton == 3) boton3Activo = true;
        else if (idBoton == 4) boton4Activo = true;

        walkPressed = boton1Activo || boton2Activo || boton3Activo || boton4Activo;
    }

    void Update()
    {
        // El Update ahora solo gestiona el Speed del Animator seg�n los flags de entrada.

        float targetSpeed = IDLE_SPEED;

        if (runPressed)
        {
            targetSpeed = RUN_SPEED; // prioridad m�xima
        }
        else if (walkPressed)
        {
            targetSpeed = WALK_SPEED;
        }
        else
        {
            targetSpeed = IDLE_SPEED;
        }

        SetSpeed(targetSpeed);
    }

    // Funciones p�blicas para UI (puedes asignarlas en EventTrigger o Button)
    public void Walk()
    {
        walkPressed = true;
        // Activar las direcciones de walk (1-4) como estado de caminar
        boton1Activo = boton2Activo = boton3Activo = boton4Activo = true;
    }

    public void WalkRelease()
    {
        walkPressed = false;
        boton1Activo = boton2Activo = boton3Activo = boton4Activo = false;
    }

    public void Run()
    {
        runPressed = true;
    }

    public void RunRelease()
    {
        runPressed = false;
    }

    private void SetSpeed(float value)
    {
        if (animator == null) return;
        animator.SetFloat("Speed", value);
    }
}
