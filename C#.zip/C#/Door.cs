using UnityEngine;
using UnityEngine.UI;

public class Door : MonoBehaviour
{
    [Header("Door")]
    public GameObject door;

    [Header("Buttons")]
    public Button buttonMinus90;   // Bot�n "-90"
    public Button buttonPlus90;    // Bot�n "+90"

    [Header("Triggers")]
    public GameObject triggerMinus90; // Trigger "-90"
    public GameObject triggerPlus90;  // Trigger "+90"

    [Header("Golem Objects To Disable")]
    public GameObject disableWhenGolemMinus90;
    public GameObject disableWhenGolemPlus90;

    private Quaternion initialDoorRotation;
    private float currentYRotation = 0f;

    private void Awake()
    {
        if (door != null)
            initialDoorRotation = door.transform.localRotation;

        // Botones desactivados al inicio
        if (buttonMinus90 != null) buttonMinus90.gameObject.SetActive(false);
        if (buttonPlus90 != null) buttonPlus90.gameObject.SetActive(false);

        // Eventos de botones
        if (buttonMinus90 != null)
        {
            buttonMinus90.onClick.RemoveAllListeners();
            buttonMinus90.onClick.AddListener(() => TryRotateDoor(-90f));
        }

        if (buttonPlus90 != null)
        {
            buttonPlus90.onClick.RemoveAllListeners();
            buttonPlus90.onClick.AddListener(() => TryRotateDoor(90f));
        }

        // Configurar triggers
        SetupTrigger(triggerMinus90, DoorTriggerZone.TriggerType.Minus90);
        SetupTrigger(triggerPlus90, DoorTriggerZone.TriggerType.Plus90);

        UpdateButtonStates();
    }

    private void SetupTrigger(GameObject triggerObj, DoorTriggerZone.TriggerType type)
    {
        if (triggerObj == null) return;

        DoorTriggerZone zone = triggerObj.GetComponent<DoorTriggerZone>();
        if (zone == null)
            zone = triggerObj.AddComponent<DoorTriggerZone>();

        zone.door = this;
        zone.type = type;
    }

    public void OnPlayerEnter(DoorTriggerZone.TriggerType type)
    {
        if (type == DoorTriggerZone.TriggerType.Minus90)
        {
            if (buttonMinus90 != null) buttonMinus90.gameObject.SetActive(true);
        }
        else if (type == DoorTriggerZone.TriggerType.Plus90)
        {
            if (buttonPlus90 != null) buttonPlus90.gameObject.SetActive(true);
        }

        UpdateButtonStates();
    }

    public void OnPlayerExit(DoorTriggerZone.TriggerType type)
    {
        if (type == DoorTriggerZone.TriggerType.Minus90)
        {
            if (buttonMinus90 != null) buttonMinus90.gameObject.SetActive(false);
        }
        else if (type == DoorTriggerZone.TriggerType.Plus90)
        {
            if (buttonPlus90 != null) buttonPlus90.gameObject.SetActive(false);
        }
    }

    private void TryRotateDoor(float deltaY)
    {
        if (door == null) return;

        float targetY = Mathf.Clamp(currentYRotation + deltaY, -90f, 90f);

        if (Mathf.Approximately(targetY, currentYRotation))
            return;

        currentYRotation = targetY;
        ApplyRotation();
        UpdateButtonStates();
    }

    private void ApplyRotation()
    {
        if (door == null) return;

        door.transform.localRotation = initialDoorRotation * Quaternion.Euler(0f, currentYRotation, 0f);
    }

    private void UpdateButtonStates()
    {
        if (buttonMinus90 != null)
            buttonMinus90.interactable = currentYRotation > -90f;

        if (buttonPlus90 != null)
            buttonPlus90.interactable = currentYRotation < 90f;
    }

    public void GolemAutoRotate(DoorTriggerZone.TriggerType type)
    {
        if (door == null) return;

        bool rotated = false;

        if (type == DoorTriggerZone.TriggerType.Minus90)
        {
            if (currentYRotation > -90f)
            {
                currentYRotation = Mathf.Max(currentYRotation - 90f, -90f);
                rotated = true;

                if (disableWhenGolemMinus90 != null)
                    disableWhenGolemMinus90.SetActive(false);
            }
        }
        else if (type == DoorTriggerZone.TriggerType.Plus90)
        {
            if (currentYRotation < 90f)
            {
                currentYRotation = Mathf.Min(currentYRotation + 90f, 90f);
                rotated = true;

                if (disableWhenGolemPlus90 != null)
                    disableWhenGolemPlus90.SetActive(false);
            }
        }

        if (rotated)
        {
            ApplyRotation();
            UpdateButtonStates();
        }
    }
}

public class DoorTriggerZone : MonoBehaviour
{
    public enum TriggerType
    {
        Minus90,
        Plus90
    }

    [HideInInspector] public Door door;
    [HideInInspector] public TriggerType type;

    private void OnTriggerEnter(Collider other)
    {
        if (door == null) return;

        if (other.CompareTag("Player"))
        {
            door.OnPlayerEnter(type);
        }
        else if (other.CompareTag("Golem"))
        {
            door.GolemAutoRotate(type);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (door == null) return;

        if (other.CompareTag("Player"))
        {
            door.OnPlayerExit(type);
        }
    }
}