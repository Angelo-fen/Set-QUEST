using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Ocilatin : MonoBehaviour
{
    [Header("Configuraci�n de Oscilaci�n")]
    [Tooltip("Arrastra aqu� el componente CanvasGroup (Alpha Group)")]
    [SerializeField] private CanvasGroup alphaGroup;

    [Tooltip("Tiempo en segundos que tarda en ir de 0 a 1 (la mitad de un ciclo completo)")]
    [SerializeField] private float tiempoDeIda = 1f;

    [Header("UI Bot�n")]
    [Tooltip("El bot�n designado que detendr� la oscilaci�n, pondr� el alpha en 0 y pausar�")]
    [SerializeField] private Button botonDesignado;

    // Variables internas de control
    private Coroutine fadeCoroutine;
    private bool estaPausado = false;

    private void Start()
    {
        // Vincular el evento del bot�n por c�digo
        if (botonDesignado != null)
        {
            botonDesignado.onClick.AddListener(PausarYAnularAlpha);
        }
        else
        {
            Debug.LogWarning("El campo 'Boton Designado' no est� asignado en el Inspector.", this);
        }

        // Iniciar la oscilaci�n autom�tica al empezar
        IniciarOscilacion();
    }

    private void OnDestroy()
    {
        // Limpiar el listener al destruir el objeto
        if (botonDesignado != null)
        {
            botonDesignado.onClick.RemoveListener(PausarYAnularAlpha);
        }
    }

    /// <summary>
    /// Inicia la oscilaci�n continua entre 0 y 1.
    /// </summary>
    public void IniciarOscilacion()
    {
        if (alphaGroup == null)
        {
            Debug.LogError("Ocilatin: Falta asignar el CanvasGroup en el Inspector.", this);
            return;
        }

        estaPausado = false;

        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
        }

        fadeCoroutine = StartCoroutine(OscilarRoutine());
    }

    private IEnumerator OscilarRoutine()
    {
        float tiempoInicio = Time.time;

        // Evitar divisi�n por cero
        if (tiempoDeIda <= 0f) tiempoDeIda = 0.1f;

        while (!estaPausado)
        {
            if (alphaGroup == null) yield break;

            float tiempoTranscurrido = Time.time - tiempoInicio;

            // Mathf.PingPong oscila suavemente entre 0 y 1 usando el tiempo de ida configurado
            float t = tiempoTranscurrido / tiempoDeIda;
            alphaGroup.alpha = Mathf.PingPong(t, 1f);

            yield return null;
        }

        fadeCoroutine = null;
    }

    /// <summary>
    /// M�todo ejecutado por el bot�n: detiene la oscilaci�n, pone el alpha en 0 de inmediato y pausa.
    /// </summary>
    public void PausarYAnularAlpha()
    {
        estaPausado = true;

        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
            fadeCoroutine = null;
        }

        if (alphaGroup != null)
        {
            alphaGroup.alpha = 0f;
        }
    }
}