using UnityEngine;

[DisallowMultipleComponent]
public class RotRupia : MonoBehaviour
{
    [Header("Target")]
    [Tooltip("Si se asigna, el objeto mantendr� su offset inicial respecto a este target.")]
    public GameObject target;

    [Header("Oscilaci�n en Y")]
    [Tooltip("Amplitud en unidades (metros) de la oscilaci�n vertical.")]
    public float bobAmplitude = 0.1f;
    [Tooltip("Frecuencia de la oscilaci�n (veces por segundo).")]
    public float bobFrequency = 1f;

    [Header("Rotaci�n")]
    [Tooltip("Velocidad de rotaci�n en grados por segundo (X, Y, Z).")]
    public Vector3 rotationSpeed = new Vector3(0f, 45f, 0f);
    [Tooltip("Cuanto mayor, m�s suave ser� la interpolaci�n de la rotaci�n.")]
    [Range(0.01f, 20f)]
    public float rotationSmoothness = 6f;

    [Header("Opciones")]
    [Tooltip("Si es true, la oscilaci�n se aplica en espacio mundial; si es false, en espacio local.")]
    public bool worldSpace = true;

    // Estado interno
    private Vector3 _initialPosition;
    private Vector3 _initialOffsetToTarget;
    private Quaternion _currentRotation;

    void Awake()
    {
        _initialPosition = transform.position;
        _currentRotation = transform.rotation;

        if (target != null)
            _initialOffsetToTarget = transform.position - target.transform.position;
        else
            _initialOffsetToTarget = Vector3.zero;
    }

    void OnValidate()
    {
        // Evitar valores no v�lidos en el inspector
        bobAmplitude = Mathf.Max(0f, bobAmplitude);
        bobFrequency = Mathf.Max(0f, bobFrequency);
        rotationSmoothness = Mathf.Clamp(rotationSmoothness, 0.01f, 100f);
    }

    void Update()
    {
        // Tiempo para la oscilaci�n
        float t = Time.time;
        float bob = Mathf.Sin(t * bobFrequency * Mathf.PI * 2f) * bobAmplitude;

        // Posici�n base (dependiendo si hay target)
        Vector3 basePos = target != null ? target.transform.position + _initialOffsetToTarget : _initialPosition;

        // Aplicar oscilaci�n en Y (world o local)
        if (worldSpace)
        {
            Vector3 worldPos = basePos;
            worldPos.y += bob;
            transform.position = worldPos;
        }
        else
        {
            // localPosition respecto al padre
            Vector3 localBase = target != null ? target.transform.InverseTransformPoint(basePos) : transform.localPosition;
            localBase.y += bob;
            transform.localPosition = localBase;
        }

        // Rotaci�n objetivo (aplicar velocidad de rotaci�n por frame)
        Quaternion targetRot = _currentRotation * Quaternion.Euler(rotationSpeed * Time.deltaTime);

        // Interpolar suavemente desde la rotaci�n actual hacia la rotaci�n objetivo
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, Mathf.Clamp01(Time.deltaTime * rotationSmoothness));

        // Actualizar rotaci�n acumulada para el siguiente frame
        _currentRotation = targetRot;
    }

    // M�todo p�blico para reiniciar la posici�n y rotaci�n iniciales (�til en runtime o editor)
    public void ResetInitialTransform()
    {
        _initialPosition = transform.position;
        _currentRotation = transform.rotation;
        if (target != null)
            _initialOffsetToTarget = transform.position - target.transform.position;
        else
            _initialOffsetToTarget = Vector3.zero;
    }
}
