using UnityEngine;
using UnityEngine.UI;

public class Aenemy : MonoBehaviour
{
    [Header("Animaci�n")]
    [Tooltip("Arrastra aqu� el componente Animator del enemigo (donde se reproducen las animaciones)")]
    public Animator animatorEnemigo;

    [Tooltip("Arrastra aqu� el Animator Controller (RuntimeAnimatorController) que contiene tu par�metro 'Golem'")]
    public RuntimeAnimatorController animatorController;

    [Header("Botones (Opcional UI)")]
    public Button boton1;
    public Button boton0;

    [Header("Colisionadores")]
    [Tooltip("Designa aqu� el colisionador normal del Golem")]
    public Collider golemCollider;
    [Tooltip("Designa aqu� el colisionador que funciona como Trigger (Zona Atack)")]
    public Collider zonaAttackCollider;

    [Header("Configuraci�n de Ataque")]
    [Tooltip("Tag del objeto que activar� la zona de ataque (Por defecto: Player)")]
    public string tagObjetivo = "Player";

    [Header("Audio de Ataque")]
    [Tooltip("Arrastra aqu� el archivo de audio (AudioClip) que sonar� al atacar o presionar el bot�n 1")]
    public AudioClip sonidoAtaque;
    [Tooltip("Componente AudioSource (se a�adir� o detectar� autom�ticamente si se deja vac�o)")]
    public AudioSource audioSource;

    // Variable interna de control
    private bool enZonaAttack = false;

    void Start()
    {
        // Le inyectamos el Controlador al Animator designado en el Inspector
        if (animatorEnemigo != null && animatorController != null)
        {
            animatorEnemigo.runtimeAnimatorController = animatorController;
        }
        else if (animatorEnemigo == null)
        {
            Debug.LogWarning("Falta asignar el Animator del enemigo en el Inspector del script Aenemy.");
        }

        // Vinculamos los botones f�sicos si los asignaste
        if (boton1 != null) boton1.onClick.AddListener(Boton1);
        if (boton0 != null) boton0.onClick.AddListener(Boton0);

        // Configuraci�n autom�tica del AudioSource por seguridad si no se asign�
        if (audioSource == null)
        {
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
            {
                audioSource = gameObject.AddComponent<AudioSource>();
            }
        }
    }

    void Update()
    {
        // Control total y a prueba de fallos desde el Update
        if (animatorEnemigo != null)
        {
            if (enZonaAttack)
            {
                animatorEnemigo.SetFloat("Golem", 1f);
            }
            else
            {
                animatorEnemigo.SetFloat("Golem", 0f);
            }
        }
    }

    //----------------------------------------
    // M�TODOS DE LOS BOTONES
    //----------------------------------------

    public void Boton1()
    {
        if (animatorEnemigo != null) animatorEnemigo.SetFloat("Golem", 1f);

        // Reproduce el sonido de ataque al presionar Bot�n 1 o entrar en la zona
        if (sonidoAtaque != null && audioSource != null)
        {
            audioSource.PlayOneShot(sonidoAtaque);
        }
    }

    public void Boton0()
    {
        if (animatorEnemigo != null) animatorEnemigo.SetFloat("Golem", 0f);
    }

    //----------------------------------------
    // L�GICA DE LA ZONA DE ATAQUE (TRIGGER)
    //----------------------------------------

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(tagObjetivo))
        {
            enZonaAttack = true;
            Boton1(); // Refuerzo la acci�n del bot�n al entrar
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag(tagObjetivo))
        {
            enZonaAttack = false;
            Boton0(); // Refuerzo la acci�n del bot�n al salir
        }
    }
}