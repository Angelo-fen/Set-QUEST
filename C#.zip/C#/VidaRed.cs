using UnityEngine;
using System.Collections;

public class VidaRed : MonoBehaviour
{
    [Header("Configuraci�n de Monitoreo")]
    [Tooltip("Array de GameObjects que se van a monitorear.")]
    public GameObject[] monitoredObjects;

    [Tooltip("Array de GameObjects especiales desactivados por defecto. El �ndice corresponder� al objeto monitoreado.")]
    public GameObject[] specialObjects;

    [Header("Tiempo")]
    [Tooltip("Duraci�n en milisegundos que el objeto especial se mantendr� activo.")]
    public float durationInMilliseconds = 500f;

    private bool[] previousStates;
    private Coroutine[] activeRoutines;

    void Start()
    {
        // Inicializar el almacenamiento de estados previos
        if (monitoredObjects != null)
        {
            previousStates = new bool[monitoredObjects.Length];
            for (int i = 0; i < monitoredObjects.Length; i++)
            {
                if (monitoredObjects[i] != null)
                {
                    previousStates[i] = monitoredObjects[i].activeSelf;
                }
            }
        }

        // Inicializar el array de corrutinas activas seg�n la cantidad de objetos especiales
        if (specialObjects != null)
        {
            activeRoutines = new Coroutine[specialObjects.Length];

            // Asegurar que todos los objetos especiales inicien desactivados
            for (int i = 0; i < specialObjects.Length; i++)
            {
                if (specialObjects[i] != null)
                {
                    specialObjects[i].SetActive(false);
                }
            }
        }
    }

    void Update()
    {
        if (monitoredObjects == null || specialObjects == null) return;

        // Revisar frame por frame el estado de cada objeto del array
        for (int i = 0; i < monitoredObjects.Length; i++)
        {
            GameObject obj = monitoredObjects[i];
            if (obj == null) continue;

            bool currentState = obj.activeSelf;

            // Detectar la transici�n exacta: de ACTIVADO (true) a DESACTIVADO (false)
            if (previousStates[i] && !currentState)
            {
                // Solo activamos si existe un objeto especial equivalente en ese �ndice
                if (i < specialObjects.Length && specialObjects[i] != null)
                {
                    TriggerSpecialEffect(i);
                }
            }

            // Actualizar el estado para el siguiente frame
            previousStates[i] = currentState;
        }
    }

    void TriggerSpecialEffect(int index)
    {
        // Si el objeto especial de este �ndice ya tiene una activaci�n en curso, la reiniciamos
        if (activeRoutines[index] != null)
        {
            StopCoroutine(activeRoutines[index]);
        }

        activeRoutines[index] = StartCoroutine(SpecialEffectRoutine(index));
    }

    IEnumerator SpecialEffectRoutine(int index)
    {
        GameObject targetSpecial = specialObjects[index];
        targetSpecial.SetActive(true);

        // Convertir milisegundos a segundos para el temporizador de Unity
        float durationInSeconds = durationInMilliseconds / 1000f;
        yield return new WaitForSeconds(durationInSeconds);

        targetSpecial.SetActive(false);
        activeRoutines[index] = null;
    }
}