using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

[RequireComponent(typeof(RectTransform))]
public class Joystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    [Header("Referencias UI")]
    public RectTransform joystickBackground; // Fondo del joystick (centro)
    public RectTransform joystickHandle;     // Handle que se arrastra

    [Header("Configuraci�n")]
    [Tooltip("Distancia m�xima (en p�xeles) que puede moverse el handle desde el centro")]
    public float handleRange = 100f;

    [Header("Botones direccionales")]
    public Button upButton;
    public Button downButton;
    public Button leftButton;
    public Button rightButton;

    // Estado interno
    private RectTransform _rectTransform;
    private Canvas _rootCanvas;
    private Button _currentPressedButton;
    private PointerEventData _pointerDataCache = new PointerEventData(null);

    void Awake()
    {
        _rectTransform = joystickBackground != null ? joystickBackground : GetComponent<RectTransform>();
        _rootCanvas = GetComponentInParent<Canvas>();
        ResetHandle();
    }

    // IPointerDownHandler
    public void OnPointerDown(PointerEventData eventData)
    {
        // Reusar pointer data para ExecuteEvents
        _pointerDataCache = eventData;
        UpdateHandlePosition(eventData);
    }

    // IDragHandler
    public void OnDrag(PointerEventData eventData)
    {
        _pointerDataCache = eventData;
        UpdateHandlePosition(eventData);
    }

    // IPointerUpHandler
    public void OnPointerUp(PointerEventData eventData)
    {
        _pointerDataCache = eventData;
        ResetHandle();
        ReleaseAllButtons();
    }

    // Actualiza la posici�n del handle seg�n el puntero y gestiona botones
    private void UpdateHandlePosition(PointerEventData eventData)
    {
        Vector2 localPoint;
        // Convertir pantalla -> punto local en el rect del background
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(_rectTransform, eventData.position, _rootCanvas ? _rootCanvas.worldCamera : null, out localPoint))
        {
            // Limitar la distancia al rango
            Vector2 clamped = Vector2.ClampMagnitude(localPoint, handleRange);
            joystickHandle.anchoredPosition = clamped;

            // Calcular �ngulo en grados (0 = derecha, 90 = arriba)
            float angle = Mathf.Atan2(clamped.y, clamped.x) * Mathf.Rad2Deg;
            angle = NormalizeAngle(angle);

            // Determinar qu� bot�n corresponde seg�n el �ngulo
            Button target = ButtonForAngle(angle);

            // Si cambi� la direcci�n, actualizar presionado
            if (target != _currentPressedButton)
            {
                // Soltar anterior
                if (_currentPressedButton != null)
                    ReleaseButton(_currentPressedButton);

                // Presionar nuevo (si no es null)
                if (target != null)
                    PressButton(target);

                _currentPressedButton = target;
            }
        }
    }

    // Normaliza �ngulo a 0..360
    private float NormalizeAngle(float a)
    {
        a %= 360f;
        if (a < 0) a += 360f;
        return a;
    }

    // Devuelve el bot�n correspondiente al �ngulo seg�n las reglas:
    // Up: 45 - 145
    // Left: 145 - 225
    // Down: 225 - 315
    // Right: 315 - 360 y 0 - 45
    private Button ButtonForAngle(float angle)
    {
        if (angle >= 45f && angle <= 145f)
            return upButton;
        if (angle > 145f && angle <= 225f)
            return leftButton;
        if (angle > 225f && angle <= 315f)
            return downButton;
        // Rango derecho (incluye 0..45 y 315..360)
        return rightButton;
    }

    // Simula "presionar" un bot�n (pointer down)
    private void PressButton(Button btn)
    {
        if (btn == null) return;
        // Ejecutar evento pointerDown para que componentes que escuchen lo reciban
        ExecuteEvents.Execute<IPointerDownHandler>(btn.gameObject, _pointerDataCache, ExecuteEvents.pointerDownHandler);
        // Opcional: tambi�n podemos invocar onClick una vez al entrar si se desea:
        // btn.onClick.Invoke();
    }

    // Simula "soltar" un bot�n (pointer up)
    private void ReleaseButton(Button btn)
    {
        if (btn == null) return;
        ExecuteEvents.Execute<IPointerUpHandler>(btn.gameObject, _pointerDataCache, ExecuteEvents.pointerUpHandler);
    }

    // Suelta todos los botones y limpia estado
    private void ReleaseAllButtons()
    {
        if (upButton != null) ReleaseButton(upButton);
        if (downButton != null) ReleaseButton(downButton);
        if (leftButton != null) ReleaseButton(leftButton);
        if (rightButton != null) ReleaseButton(rightButton);
        _currentPressedButton = null;
    }

    // Devuelve el handle a la posici�n central
    private void ResetHandle()
    {
        if (joystickHandle != null)
            joystickHandle.anchoredPosition = Vector2.zero;
    }

    // M�todo p�blico para forzar soltar (por si otro script lo necesita)
    public void ForceRelease()
    {
        ResetHandle();
        ReleaseAllButtons();
    }
}
